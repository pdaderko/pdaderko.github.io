//Program by DogP (Pat Daderko) that draws Hi, then allows the individual lines to be moved intependantly
//Uses Direct Framebuffer writing

#include <c:\gccvb\bin\libgccvb.h>

/*
buffvln draws a vertical line in the L/R Display Buffers
buffhln draws a horizontal line in the L/R Display Buffers
buffln draws a line in the L/R Display Buffers between two points

How to use functions:
buffvln(int source x-coordinate, source y-coordinate, int length of line, int shade of red (1-3), int parallax)
buffhln(int source x-coordinate, source y-coordinate, int length of line, int shade of red (1-3), int parallax)
buffln(int source x-coordinate, source y-coordinate, int destination x-coordinate, int destination y-coordinate, int shade of red (1-3), int parallax)
*/

int main ()
{	
	int length = 0;  // length of line
	int l1; // line 1
	int l2; // line 2
	int l3; // line 3
	int l4; // line 4

	vbSetWorld(31, 0x0040, 0, 0, 0, 0, 0, 0, 0, 0); // Blank world and END bit set 
	
	vbDisplayOn(); // turns the display on
	vbDisplayShow(); // shows the display

	//Does the animated drawing of the word Hi
	for (length = 0; length <= 128; length++)
	{	
		buffvln(15, 32, length, 3, 0);
		vbWaitFrame(1);
	}
	for (length = 0; length <= 48; length++)
	{	
		buffvln(15, 32, 128, 3, 0);
		buffhln(16, 96, length, 3, 0);
		vbWaitFrame(1);
	}
	for (length = 0; length <= 128; length++)
	{	
		buffvln(15, 32, 128, 3, 0);
		buffhln(16, 96, 48, 3, 0);
		buffvln(65, 32, length, 3, 0);
		vbWaitFrame(1);
	}
	for (length = 0; length <= 64; length++)
	{	
		buffvln(15, 32, 128, 3, 0);
		buffhln(16, 96, 48, 3, 0);
		buffvln(65, 32, 128, 3, 0);
		buffvln(128, 96, length, 3, 0);
		vbWaitFrame(1);
	}
	for (length = 0; length <= 16; length++)
	{	
		buffvln(15, 32, 128, 3, 0);
		buffhln(16, 96, 48, 3, 0);
		buffvln(65, 32, 128, 3, 0);
		buffvln(128, 96, 64, 3, 0);
		buffvln(128, 48, length, 3, 0);
		vbWaitFrame(1);
	}
	
	while (1) //allows the lines in Hi to be moved independantly
	{
		if (vbReadPad() & K_LU)
		{
			l1--;
			vbWaitFrame(2);
		}
		if (vbReadPad() & K_LL)
		{
			l2--;
			vbWaitFrame(2);
		}
		if (vbReadPad() & K_LR)
		{
			l3--;
			vbWaitFrame(2);
		}
		if (vbReadPad() & K_LD)
		{
			l4--;
			vbWaitFrame(2);
		}
		if (vbReadPad() & K_RU)
		{
			l1++;
			vbWaitFrame(2);
		}
		if (vbReadPad() & K_RL)
		{
			l2++;
			vbWaitFrame(2);
		}
		if (vbReadPad() & K_RR)
		{
			l3++;
			vbWaitFrame(2);
		}
		if (vbReadPad() & K_RD)
		{
			l4++;
			vbWaitFrame(2);
		}
		buffvln((15+l1), 32, 128, 3, 0);
		buffhln(16, (96+l2), 48, 3, 0);
		buffvln((65+l3), 32, 128, 3, 0);
		buffvln((128+l4), 96, 64, 3, 0);
		buffvln((128+l4), 48, 16, 3, 0);
	}

	return 0;
}
