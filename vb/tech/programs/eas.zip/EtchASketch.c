//An Etch-A-Sketch program by DogP (Pat Daderko)
//uses Direct Framebuffer writing with screen refreshing disabled

#include <c:\gccvb\bin\libgccvb.h>
#include <c:\gccvb\bin\easpics.h>

int main ()
{	
	int x = 71; // starting x
	int y = 29; // starting y
	int shade = 3; // starting color (bright red)
	int parallax = 0; // starting parallax value
	int count; // counter used for pauses

	copymem((void*) CharSeg0, (void*) chEAS, 235 * 16); // Copy the chars to CharMap 0
	copymem((void*) BGMap(0), (void*) bgEAS, 1024 * 16);  // Copy the char index to BGMap 0
	vbSetWorld(31, 0xC000, 39, 0, 0, 0, 0, 0, 307, 224); // set up the Etch-A-Sketch board
	vbSetWorld(30, 0x0040, 0, 0, 0, 0, 0, 0, 0, 0); // Blank world and END bit set 
	
	vbDisplayOn(); // turns the display on
	vbDisplayShow(); // shows the display
	
	for (count=0; count < 200000; count++); // similar to waitframe, except not dependant on display
	
	VIP_REGS[XPCTRL] = VIP_REGS[XPSTTS] | XPEN; // sets the XPEN bit to make sure Etch-A-Sketch board shows up
	while (!(VIP_REGS[XPSTTS] & XPBSY1)); // makes sure to freeze screen on framebuffer 0
	VIP_REGS[XPCTRL] = VIP_REGS[XPSTTS] & ~XPEN; // turn off screen refreshing so once a dot is drawn it stays there until refreshed again (start pressed)

	while (1)
	{
		if ((vbReadPad() & K_A) && (shade < 3))
		{
			shade++; // makes pixel lighter
			for (count=0; count < 100000; count++); // pause
		}
		if ((vbReadPad() & K_LL) && (y > 29))
		{
			y--; // moves dot up
			for (count=0; count < 10000; count++); // pause
		}
		if ((vbReadPad() & K_LR) && (y < 168))
		{
			y++; // moves dot down
			for (count=0; count < 10000; count++); // pause
		}
		if ((vbReadPad() & K_B) && (shade > 0))
		{
			shade--; // makes pixel darker
			for (count=0; count < 100000; count++); // pause
		}
		if ((vbReadPad() & K_LT) && ((x - parallax) < 314) && ((x - parallax) > 71) && ((x + parallax) < 314) && ((x + parallax) > 71))
		{
			parallax++; // moves pixel further away
			for (count=0; count < 100000; count++); // pause
		}
		if ((vbReadPad() & K_RR) && ((x - parallax) < 314) && ((x + parallax) < 314))
		{
			x++; // moves dot right
			for (count=0; count < 10000; count++); // pause
		}
		if ((vbReadPad() & K_RL) && ((x - parallax) > 71) && ((x + parallax) > 71))
		{
			x--; // moves dot left
			for (count=0; count < 10000; count++); // pause
		}
		if ((vbReadPad() & K_RT) && ((x - parallax) < 314) && ((x - parallax) > 71) && ((x + parallax) < 314) && ((x + parallax) > 71))
		{
			parallax--; // moves pixel closer
			for (count=0; count < 100000; count++); // pause
		}
		if (vbReadPad() & K_STA)
		{
			VIP_REGS[XPCTRL] = VIP_REGS[XPSTTS] | XPEN; // sets the XPEN bit to refresh the screen
			while (!(VIP_REGS[XPSTTS] & XPBSY1)); // makes sure to freeze screen on framebuffer 0
			VIP_REGS[XPCTRL] = VIP_REGS[XPSTTS] & ~XPEN; // turn screen refreshing off again
			shade = 3; // resets the color
			parallax = 0; // resets the parallax
		}
		buffhln(x, y, 0, shade, parallax); // draws pixel with buffhln (more efficient than buffvln or buffln) with length of 0 (so it's only one dot)
	}
	return 0;
}
