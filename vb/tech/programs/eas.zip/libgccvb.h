// DogP's gccVB header

#ifndef _LIBGCCVB_H_
#define _LIBGCCVB_H_

// Easier to type/remember...
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

typedef unsigned char BYTE;
typedef unsigned short HWORD;
typedef unsigned long WORD;

HWORD* const VIP_REGS =		(HWORD*)0x0005F800;
HWORD* const BGMM =		(HWORD*)0x00020000;
HWORD* const WAM =		(HWORD*)0x0003D800;
HWORD* const COLUMN_TABLE =	(HWORD*)0x0003DC00;
HWORD* const OAM =		(HWORD*)0x0003E000;

/****** VIP Register Mnemonics ******/
#define INTPND	0x00
#define INTENB	0x01
#define INTCLR	0x02

#define DPSTTS	0x10
#define DPCTRL	0x11
#define BRTA	0x12
#define BRTB	0x13
#define BRTC	0x14
#define REST	0x15

#define FRMCYC	0x17
#define CTA	0x18

#define XPSTTS	0x20
#define XPCTRL	0x21
#define VER	0x22

#define SPT0	0x24
#define SPT1	0x25
#define SPT2	0x26
#define SPT3	0x27

#define GPLT0	0x30
#define GPLT1	0x31
#define GPLT2	0x32
#define GPLT3	0x33

#define JPLT0	0x34
#define JPLT1	0x35
#define JPLT2	0x36
#define JPLT3	0x37

#define BKCOL	0x38

WORD* SND_REGS = (WORD*)0x01000000;

/***** Sound Register Mnemonics *****/
/* none, currently... */

BYTE* HW_REGS = (BYTE*)0x02000000;
/***** Hardware Register Mnemonics *****/
#define	CCR	0x00	// Link Port Control 1
#define	CCSR	0x04	// Link Port Control 2
#define	CDTR	0x08	// Link Port Transmit
#define	CDRR	0x0C	// Link Port Receive
#define	SDLR	0x10	// Keypad Low Byte
#define	SDHR	0x14	// Keypad High Byte
#define	TLR	0x18	// Timer Low Byte
#define	THR	0x1C	// Timer High Byte
#define	TCR	0x20	// Timer Control Register
#define	WCR	0x24	// Wait-state Control Register
#define	SCR	0x28	// Keypad (controller) Control Register

/***** Handy Video RAM Locations *****/
#define	CharSeg0	0x6000
#define	CharSeg1	0xE000
#define	CharSeg2	0x16000
#define	CharSeg3	0x1E000
#define BGMMBase	0x20000
#define BGMap(x)	(BGMMBase+(0x2000*x))
#define World(x)	(0x3D800+(x*0x20))
#define	ObjectSeg	0x3E000
#define	Object(x)	(0x3E000+(8*x))

/***** World Functions *****/
void vbSetWorld (int nw, HWORD header, HWORD gx, HWORD gp, HWORD gy, HWORD mx, HWORD mp, HWORD my, HWORD width, HWORD height) {
	HWORD tmp = (nw<<5)>>1;

	WAM[tmp++] = header;
	WAM[tmp++] = gx;
	WAM[tmp++] = gp;
	WAM[tmp++] = gy;
	WAM[tmp++] = mx;
	WAM[tmp++] = mp;
	WAM[tmp++] = my;
	WAM[tmp++] = width;
	WAM[tmp] = height;
}

/* Macros for world manipulation */
#define WORLD_HEAD(n,head)		WAM[((n << 5) >> 1)    ] = head;
#define WORLD_GSET(n,gx,gp,gy)	WAM[((n << 5) >> 1) + 1] = gx;\
								WAM[((n << 5) >> 1) + 2] = gp;\
								WAM[((n << 5) >> 1) + 3] = gy;
#define WORLD_MSET(n,mx,mp,my)	WAM[((n << 5) >> 1) + 4] = mx;\
								WAM[((n << 5) >> 1) + 5] = mp;\
								WAM[((n << 5) >> 1) + 6] = my;
#define WORLD_SIZE(n,w,h)		WAM[((n << 5) >> 1) + 7] = w;\
								WAM[((n << 5) >> 1) + 8] = h;
#define WORLD_PARAM(n,p)		WAM[((n << 5) >> 1) + 9] = (p << 4);

/* "vbSetWorld" header flags */
/* (OR these together to build a World Header) */

#define	WRLD_ON		0xC000
#define	WRLD_LON	0x8000
#define	WRLD_RON	0x4000
#define	WRLD_OBJ	0x3000
#define	WRLD_AFFINE	0x2000
#define	WRLD_HBIAS	0x1000
#define	WRLD_BGMAP	0x0000

#define	WRLD_1x1	0x0000
#define	WRLD_1x2	0x0100
#define	WRLD_1x4	0x0200
#define	WRLD_1x8	0x0300
#define	WRLD_2x1	0x0400
#define	WRLD_2x2	0x0500
#define	WRLD_2x4	0x0600
#define	WRLD_4x2	0x0900
#define	WRLD_4x1	0x0800
#define	WRLD_8x1	0x0C00

#define	WRLD_OVR	0x0080
#define	WRLD_END	0x0040


/***** Object (sprite) Functions *****/

void vbSetObject (HWORD n, BYTE header, HWORD x, HWORD p, HWORD y, HWORD chr)
{
	HWORD temp1, temp2, signbit;

	signbit=(p & 0x8000) >> 2;

	temp1 = (header & 0xC0) << 8;
	temp2 = (p & 0xFF) | signbit | temp1;

	temp1 = ((header & 0x3C) << 10) | (chr & 0x7FF);

	OAM[n<<2] = x;
	OAM[(n<<2)+1] = temp2;
	OAM[(n<<2)+2] = y;
	OAM[(n<<2)+3] = temp1;
}

/*** (Obsoleted by vbSetObject and the OBJ_* macros...)
void vbObjectMove (int num, int x, int y, int p)
{
	HWORD rmw;

	OAM[(n << 2)] = x;

	rmw = OAM[(n << 2) + 1] & 0xC000;
	OAM[(n << 2) + 1] = rmw | p;

	OAM[(n << 2) + 2] = y;
}
***/

#define OBJ_XSET(n,x)	OAM[n << 2] = x;
#define OBJ_YSET(n,y)	OAM[(n << 2) + 2] = y;
#define OBJ_PSET(n,p)	OAM[(n << 2) + 1] = (OAM[(n << 2) + 1] & 0xC000) | p;
#define OBJ_CSET(n,c)	OAM[(n << 2) + 3] = (OAM[(n << 2) + 3] & 0xF000) | (HWORD)c;
#define OBJ_HSET(n,h)	OAM[(n << 2) + 3] = (OAM[(n << 2) + 3] & 0xDFFF) | (((HWORD)h << 13) & 0x2000);
#define OBJ_VSET(n,v)	OAM[(n << 2) + 3] = (OAM[(n << 2) + 3] & 0xEFFF) | (((HWORD)h << 12) & 0x1000);
// #define OBJ_PALSET(n,pal)
// #define OBJ_VIS(n,v)

/* "vbSetObject" header flags */
/* (OR these together to build an Object Header) */
#define	OBJ_ON		0x00C0
#define	OBJ_LON		0x0080
#define	OBJ_RON		0x0040

#define	OBJ_PAL0	0x0000
#define	OBJ_PAL1	0x0010
#define	OBJ_PAL2	0x0020
#define	OBJ_PAL3	0x0030

#define	OBJ_HFLIP	0x0008
#define	OBJ_VFLIP	0x0004

/* Keypad Definitions */
#define K_ANY	0xFFFC		/* All keys - bat/sgn			*/
#define K_BTNS	0x303C		/* All buttons; no d-pads		*/
#define K_PWR	0x0001		/* Low Battery					*/
#define K_SGN	0x0002		/* Signature; 1 = Standard Pad	*/
#define K_A	0x0004		/* A Button						*/
#define K_B	0x0008		/* B Button						*/
#define K_RT	0x0010		/* R Trigger					*/
#define K_LT	0x0020		/* L Trigger					*/
#define K_RU	0x0040		/* Right Pad, Up				*/
#define K_RR	0x0080		/* Right Pad, Right				*/
#define K_LR	0x0100		/* Left Pad,  Right				*/
#define K_LL	0x0200		/* Left Pad,  Left				*/
#define K_LD	0x0400		/* Left Pad,  Down				*/
#define K_LU	0x0800		/* Left Pad,  Up				*/
#define K_STA	0x1000		/* Start Button					*/
#define K_SEL	0x2000		/* Select Button				*/
#define K_RL	0x4000		/* Right Pad, Left				*/
#define K_RD	0x8000		/* Right Pad, Down				*/

/*                NEW STUFF FROM VUCC                */
/*	World attribute */
#define	WA_Ctl		0x0000 	/* World attribute control data */
#define	WA_GX		0x0002 	/* BG Destination X*/
#define	WA_GP		0x0004 	/* BG Destination Paralax*/
#define	WA_GY		0x0006 	/* BG Destination Y*/
#define	WA_MX		0x0008 	/* BG Source X*/
#define	WA_MP		0x000a 	/* BG Source Paralax*/
#define	WA_MY		0x000c 	/* BG Source Y*/
#define	WA_W		0x000e 	/* Window Width*/
#define	WA_H		0x0010 	/* Window Hight*/
#define	WA_PB		0x0012 	/* Param_Base*/
#define	WA_OC		0x0014 	/* OverPlane_Character*/
#define	WA_Size		0x0020 	/* Size*/
#define	WRLD_OFF	0xBFFE
#define	WRLD_LOFF	0x7FFF
#define	WRLD_ROFF	0x3FFF
/*	Object attribute */
#define	JX		0 	/* Display pointer X*/
#define	JP		2 	/* Paralax*/
#define	JY		4 	/* Display pointer Y*/
#define	JCA		6 	/* Character No.*/
#define	JLON		0x8000 	/* */
#define	JRON		0x4000 	/* */
#define	SCX1		0x0000 	/* 1 Segment */
#define	SCX2		0x0400 	/* 2 Segment */
#define	SCX3		0x0800 	/* 3 Segment */
#define	SCX4		0x0c00 	/* 4 Segment */
#define	SCY1		0x0000 	/* 1 Segment */
#define	SCY2		0x0200 	/* 2 Segment */
#define	SCY3		0x0400 	/* 3 Segment */
#define	SCY4		0x0600 	/* 4 Segment */
#define	OVEROFF		0x0000 	/* Over Plane off�iIt designates around BG as the repeat character�j*/
/*	The control which is the rear end */
#define	K_Int_Dis	0x80 	/* It clears the key-in interruption and interrupts and makes �f�B�X�C�l�[�u�� */
#define	K_Int_Enb	0x00 
#define	ParaS		0x20 	/* When doing software loading, the �� and others rear end signal is generated */
#define	ParaH		0x00 
#define	Soft_CK		0x10 	/* When doing software loading, when,1 is written, the transfer �� �� �� �� is generated.  */
#define	HW_SI		0x04 	/* The key loading by the hardware starts. */
#define	SI_Stat		0x02 	/* It is while 1 the key loading by the hardware.  */
#define	S_Dis		0x01	/* Hardware loading suspension/inhibitation */
#define	S_Abt		0x00 	/* Hardware loading authorization */
#define	WORLD_ATT31	0x3dbe0
#define	CHR_RAM		0x78000 /* Character RAM */
/*	Indicatory control register flag (DPSTTS,DPCTRL) */
#define	LOCK		0x0400 			/* VPU SELECT CTA */
#define	LOCKOFF		LOCK^0xffff 
#define	SYNCE		0x0200 			/* L,R_SYNC TO VPU */
#define	SYNCEOFF	SYNCE^0xffff 
#define	RE		0x0100 			/* MEMORY REFLASH CYCLE ON */
#define	REOFF		RE^0xffff 
#define	DISP		0x0002 			/* DISPLAY ON */
#define	DISPOFF		DISP^0xffff 
#define	DPRST		0x0001 			/* RESET VPU COUNTER AND WAIT FCLK */
#define	DPRSTOFF	DPRST^0xffff 
#define	FCLK		0x0080 			
#define	SCANRDY		0x0040 
/*	Register for interrupt control	*/
#define	TIMEERR		0x8000
#define	XPEND		0x4000
#define	SBHIT		0x2000 //serial button hit?
#define	FRAMESTART	0x0010
#define	GAMESTART	0x0008
#define	RFBEND		0x0004
#define	LFBEND		0x0002
#define	SCANERR		0x0001
/*	Register for drawing control */
#define	XPEN		0x0002 	/* Start of drawing */
#define	XPENOFF		XPEN^0xffff 
#define	XPRST		0x0001 	/* Forcing idling */
#define	XPRSTOFF	XPRST^0xFFFF 
#define	SBOUT		0x8000 	/* In FrameBuffer drawing included */
#define	OVERTIME	0x0010 	/* Processing */
#define	XPBSYI		0x0000 	/* Idling */
#define	XPBSY0		0x0004 	/* In the midst of FrameBuffer0 picture editing */
#define	XPBSY1		0x0008 	/* In the midst of FrameBuffer1 picture editing */
#define	XPBSYR		0x000C 	/* In the midst of drawing processing reset */
/*                END NEW STUFF FROM VUCC                */

/* Reads the keypad, returns the result in a HWORD */
HWORD vbReadPad (void) {
	HW_REGS[SCR] = 0x84;
	while(HW_REGS[SCR] & 2);
	return (HW_REGS[SDHR] << 8) | HW_REGS[SDLR];
}

/* Turn the display on */
void vbDisplayOn () {
	VIP_REGS[REST] = 0;
	VIP_REGS[XPCTRL] = VIP_REGS[XPSTTS] | XPEN;
	VIP_REGS[DPCTRL] = VIP_REGS[DPSTTS] | SYNCE|RE|DISP;
	VIP_REGS[FRMCYC] = 0;
	VIP_REGS[INTCLR] = VIP_REGS[INTPND];
	while (!(VIP_REGS[DPSTTS] & 0x3C));  //required?

	VIP_REGS[BRTA]  = 0;
	VIP_REGS[BRTB]  = 0;
	VIP_REGS[BRTC]  = 0;
	VIP_REGS[GPLT0] = 0x00e4;
	VIP_REGS[GPLT1] = 0x009c;
	VIP_REGS[GPLT2] = 0x0078;
	VIP_REGS[GPLT3] = 0x00d8;
	VIP_REGS[JPLT0] = 0x00e0;
	VIP_REGS[JPLT1] = 0x009c;
	VIP_REGS[JPLT2] = 0x0078;
	VIP_REGS[JPLT3] = 0x00d8;
	VIP_REGS[BKCOL] = 0;	/* Clear the screen to black before rendering */
}

static BYTE colTable[128] = {
	0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe,
	0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe,
	0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe,
	0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe,
	0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe,
	0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe,
	0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe,
	0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xe0, 0xbc,
	0xa6, 0x96, 0x8a, 0x82, 0x7a, 0x74, 0x6e, 0x6a,
	0x66, 0x62, 0x60, 0x5c, 0x5a, 0x58, 0x56, 0x54,
	0x52, 0x50, 0x50, 0x4e, 0x4c, 0x4c, 0x4a, 0x4a,
	0x48, 0x48, 0x46, 0x46, 0x46, 0x44, 0x44, 0x44,
	0x42, 0x42, 0x42, 0x40, 0x40, 0x40, 0x40, 0x40,
	0x3e, 0x3e, 0x3e, 0x3e, 0x3e, 0x3e, 0x3e, 0x3c,
	0x3c, 0x3c, 0x3c, 0x3c, 0x3c, 0x3c, 0x3c, 0x3c,
	0x3c, 0x3c, 0x3c, 0x3c, 0x3c, 0x3c, 0x3c, 0x3c
};

/* Setup the default Column Table */
void vbSetColTable(void) {
	int i;

	for (i = 0; i < 128; i++) {
		COLUMN_TABLE[i] = colTable[i];
		COLUMN_TABLE[i + 0x0080] = colTable[127 - i];
		COLUMN_TABLE[i + 0x0100] = colTable[i];
		COLUMN_TABLE[i + 0x0180] = colTable[127 - i];
	}
}

/* Call this after the display is on and you want the image to show up */
void vbDisplayShow (void) {
	VIP_REGS[BRTA]  = 0x0C;
	VIP_REGS[BRTB]  = 0x28;
	VIP_REGS[BRTC]  = 0x30;
}

/* Call this to hide the image; e.g. while setting things up */
void vbDisplayHide (void) {
	VIP_REGS[BRTA]  = 0;
	VIP_REGS[BRTB]  = 0;
	VIP_REGS[BRTC]  = 0;
}

/* Delay execution - OLD WAITFRAME */
/*void vbWaitFrame (int count) {
	int i = 0,
		tmp;

	for (i = 0; i <= count; i++) {
		tmp = VIP_REGS[XPSTTS];
		while (tmp == VIP_REGS[XPSTTS]);
	}
}*/

/* Delay execution */
void vbWaitFrame(u16 count) {
	u16 i,tmp;
	for (i = 0; i <= count; i++) {
	while (!(VIP_REGS[XPSTTS] & XPBSYR));
	while (VIP_REGS[XPSTTS] & XPBSYR);
	}
}

void vbFXFadeIn (int wait) {
	int i;

	for (i = 0; i <= 32; i++) {
		vbWaitFrame(wait);
		VIP_REGS[BRTA] = i;
		VIP_REGS[BRTB] = i*2;
		VIP_REGS[BRTC] = i;
	}
}

void vbFXFadeOut (int wait) {
	int i;

	for (i = 32; i >= 0; i--) {
		vbWaitFrame(wait);
		VIP_REGS[BRTA] = i;
		VIP_REGS[BRTB] = i*2;
		VIP_REGS[BRTC] = i;
	}
}

/* Macro to set the brightness for the colors */
#define SET_BRIGHT(a,b,c)       VIP_REGS[BRTA]=a; \
                                VIP_REGS[BRTB]=b; \
                                VIP_REGS[BRTC]=c;

/* Macro to set the GPLT (BGMap palette) */
#define SET_GPLT(n,pal)         VIP_REGS[GPLT0+n]=pal;

/* Macro to set the JPLT (OBJ palette) */
#define SET_JPLT(n,pal)         VIP_REGS[JPLT0+n]=pal;

u32* const   L_FRAME0 =   (u32*)0x00000000;                // L FrameBuff0
u32* const   L_FRAME1 =   (u32*)0x00008000;                // L FrameBuff1
u32* const   R_FRAME0 =   (u32*)0x00010000;                // R FrameBuff0
u32* const   R_FRAME1 =   (u32*)0x00018000;                // R FrameBuff1

u8* const   SAVERAM =   (u8*)0x06000000;                // Cartridge's Battery-backed SRAM

/***** Ancillary Functions *****/

// Copy a block of data from one area in memory to another.
void copymem (BYTE* dest, const BYTE* src, int num) {
	int i;
	for (i = 0; i < num; i++) dest[i] = src[i];
}

// Set each byte in a block of data to a given value.
void setmem (BYTE* dest, BYTE src, int num) {
	int i;
	for (i = 0; i < num; i++) dest[i] = src;
}

/*	Copy a block of data from one area in memory to another,
adding a given value to each byte, first.	*/
void addmem(BYTE* dest, const BYTE* src, int num, BYTE offset) {
 	int i;
	for (i = 0; i < num; i++) dest[i] = (src[i] + offset);
}

void vbTextOut (int bgmap, int col, int row, char t_string[])
/* The font must reside in Character segment 3 */
{
	int i = 0;
	int pos = row * 64 + col;
	while(t_string[i])
	{
		BGMM[(0x1000 * bgmap) + pos + i] = (HWORD)t_string[i] - 32 + 0x600;
		i++;
	}
}

void buffvln(int xcoord, int ycoord, int length, int shade, int parallax)
// Draws a vertical line in the L/R Display Buffers
{
	int pos;
	int prevpos = 0;
	int shift = (ycoord & 0x0F);
	int offset = ((xcoord << 4) + (ycoord >> 4));
	int data = 0;
	parallax <<= 4;

	for (pos = 0; pos <= length; pos++)
	{
		data |= (shade << (shift << 1));
		shift++;
		if ((shift & 0x0F) == 0)
		{
			L_FRAME0[(offset + (pos >> 4) - parallax)] |= data;
			R_FRAME0[(offset + (pos >> 4) + parallax)] |= data;
			prevpos = (pos + 16);
			shift = 0;
			data = 0;
		}
	}
	if (shift != 0)
	{
		L_FRAME0[(offset + (prevpos >> 4) - parallax)] |= data;
		R_FRAME0[(offset + (prevpos >> 4) + parallax)] |= data;
	}
}

void buffhln(int xcoord, int ycoord, int length, int shade, int parallax)
// Draws a horizontal line in the L/R Display Buffers
{
	int pos;
	int offset = ((xcoord << 4) + (ycoord >> 4));
	int data;
	
	for (pos = 0; pos <= (ycoord & 0x0F); pos++)
		data = (shade << (pos << 1));
	for (pos = 0; pos <= length; pos++)
	{
		L_FRAME0[((pos - parallax) << 4) + offset] |= data;
		R_FRAME0[((pos + parallax) << 4) + offset] |= data;
	}
}

void buffln(int sxcoord, int sycoord, int dxcoord, int dycoord, int shade, int parallax)
// Draws a line in the L/R Display Buffers between two points

{
	int pos;
	int ylen = (dycoord - sycoord);
	int xlen = (dxcoord - sxcoord);
	int remainder;
	int fill;
	int slide = 0;
	int slope;
	int nextpos;
	int remmult = 1;
	int lenplus;
	int temp;
	//vars for horizontal/vertical drawing embedded
	int pos1;
	int thecoord;
	int offset;
	int length;
	int prevpos;
	int shift;
	int data;
	
	if (((xlen + ylen) < 0) || (((xlen + ylen) == 0) && (dxcoord < sxcoord))) // flip so any coordinates work for source or destination
	{
		temp = sxcoord;
		sxcoord = dxcoord;
		dxcoord = temp;
		temp = sycoord;
		sycoord = dycoord;
		dycoord = temp;
		xlen = (dxcoord-sxcoord);
		ylen = (dycoord-sycoord);
	}
		
	if (xlen < 0) // actually make it the length
		xlen = ~xlen + 1;
	if (ylen < 0)
		ylen = ~ylen + 1;

	if (ylen == 0)			// prevent div by 0 and make more efficient
	{
		buffhln(sxcoord, sycoord, xlen, shade, parallax);
		return;
	}
	else if (xlen == 0)		// prevent div by 0 and make more efficient
	{
		buffvln(sxcoord, sycoord, ylen, shade, parallax);
		return;
	}
	
	if ((xlen / ylen) < 1)		// Y longer than X
	{
		ylen++;
		lenplus = (xlen + 1);
		slope = (ylen / lenplus);
		remainder = (ylen % lenplus);
		nextpos = sycoord;
		for (pos = 0; pos <= xlen; pos++)
		{
			if (pos == ((remmult * lenplus) / (remainder + 1)))
			{
				fill = 0;
				slide++;
				if (remmult < remainder)
					remmult++;
			}
			else
				fill = -1;

			if ((dxcoord-sxcoord) < 0)
			{
				prevpos = 0;
				shift = (nextpos & 0x0F);
				data = 0;
				length = (slope + fill);
				thecoord = (sxcoord - pos);
				offset = ((thecoord << 4) + (nextpos >> 4));
				parallax <<= 4;
			
				for (pos1 = 0; pos1 <= length; pos1++)
				{
					data |= (shade << (shift << 1));
					shift++;
					if ((shift & 0x0F) == 0)
					{
						L_FRAME0[(offset + (pos1 >> 4) - parallax)] |= data;
						R_FRAME0[(offset + (pos1 >> 4) + parallax)] |= data;
						prevpos = (pos1 + 16);
						shift = 0;
						data = 0;
					}
				}
				if (shift != 0)
				{
					L_FRAME0[(offset + (prevpos >> 4) - parallax)] |= data;
					R_FRAME0[(offset + (prevpos >> 4) + parallax)] |= data;
				}
			}
			else
			{
				prevpos = 0;
				shift = (nextpos & 0x0F);
				data = 0;
				length = (slope + fill);
				thecoord = (sxcoord + pos);
				offset = ((thecoord << 4) + (nextpos >> 4));
				parallax <<= 4;
			
				for (pos1 = 0; pos1 <= length; pos1++)
				{
					data |= (shade << (shift << 1));
					shift++;
					if ((shift & 0x0F) == 0)
					{
						L_FRAME0[(offset + (pos1 >> 4) - parallax)] |= data;
						R_FRAME0[(offset + (pos1 >> 4) + parallax)] |= data;
						prevpos = (pos1 + 16);
						shift = 0;
						data = 0;
					}
				}
				if (shift != 0)
				{
					L_FRAME0[(offset + (prevpos >> 4) - parallax)] |= data;
					R_FRAME0[(offset + (prevpos >> 4) + parallax)] |= data;
				}
			}
			nextpos = (sycoord + (pos + 1) * slope + slide);
		}
	}

	else			// X longer or same as Y
	{
		xlen++;
		lenplus = (ylen + 1);
		slope = (xlen / lenplus);
		remainder = (xlen % lenplus);
		nextpos = sxcoord;
		for (pos = 0; pos <= ylen; pos++)
		{
			if (pos == ((remmult * lenplus) / (remainder + 1)))
			{
				fill = 0;
				slide++;
				if (remmult < remainder)
					remmult++;
			}
			else
				fill = -1;
			
			if ((dycoord-sycoord) < 0)
			{
				thecoord = (sycoord - pos);
				offset = ((nextpos << 4) + (thecoord >> 4));
				length = (slope + fill);
				
				for (pos1 = 0; pos1 <= (thecoord & 0x0F); pos1++)
					data = (shade << (pos1 << 1));
				for (pos1 = 0; pos1 <= length; pos1++)
				{
					L_FRAME0[((pos1 - parallax) << 4) + offset] |= data;
					R_FRAME0[((pos1 + parallax) << 4) + offset] |= data;
				}
			}
			else
			{
				thecoord = (sycoord + pos);
				offset = ((nextpos << 4) + (thecoord >> 4));
				length = (slope + fill);
				
				for (pos1 = 0; pos1 <= (thecoord & 0x0F); pos1++)
					data = (shade << (pos1 << 1));
				for (pos1 = 0; pos1 <= length; pos1++)
				{
					L_FRAME0[((pos1 - parallax) << 4) + offset] |= data;
					R_FRAME0[((pos1 + parallax) << 4) + offset] |= data;
				}
			}
			nextpos = (sxcoord + (pos + 1) * slope + slide);
		}
	}
}

int readpixel(int xcoord, int ycoord, int parallax)
// Reads the data of a pixel
{
	int pos;
	int offset = ((xcoord << 4) + (ycoord >> 4));
	int data;
	
	data = L_FRAME0[((0 - parallax) << 4) + offset];
	data &= R_FRAME0[(parallax << 4) + offset];
	
	for (pos = 0; pos != (ycoord & 0x0F); pos++); // gets pos to the right position

	return ((data >> (pos << 1)) & 3); // shifts to first 2 bits and masks
}

int randseed()
/* When run at startup gets a random number based on the changing CTA */
{
	int random = 1;
	int rand;
	int prevnum = 0;
	int count = 1;
	
	while (count < 30000)	//repeat through many times to make more random and to allow the CTA value to change multiple times
	{
		rand = (*(BYTE*)(0x0005F830));	//CTA
		if (random == 0)		//prevent % by zero
			random = 1;
			
		random += ((rand*count) + (count%random));	//just randomly doing stuff to the number
	
		if (rand == prevnum)		//if the CTA value doesnt change then count up
			count++;
		else
			count = 0;		//if the number does change then restart the counter
		prevnum = rand;			//keep track of the last number
	}
	return random;		//returns the random seed
}

int randnum(int seed, int randnums)
/* Returns a random number in the requested range from the random seed */
{
	return (seed%randnums);	//returns the random number
}

/////////////////LB's STUFF

/*void vbPrint(u8 bgmap, u16 col, u16 row, char t_string[], u16 bplt)
{
// Font consists of the last 256 chars (1792-2047)
	u16 i = 0,
		pos = 0,
		x = col,
		y = row;

	while(t_string[i])
	{
		pos = (y << 6) + x;

		switch(t_string[i])
		{
			case 7:
				// Bell (!)
				break;
			case 9:
				// Horizontal Tab (?)
				x = (x / 4 + 1) * 4;
				break;
			case 10:
				y++;
				x = col;
				break;
			default:
				BGMM[(0x1000 * bgmap) + pos] = ((u16)t_string[i] + 0x700) | (bplt << 14);
				if (x++ > 63)
				{
					x = col;
					y++;
				}
				break;
		}
	}
}*/

void vbPrint(BYTE bgmap, HWORD x, HWORD y, BYTE *t_string, WORD bplt)
{
/* Font consists of the last 256 chars (1792-2047) */
	u16 i=0,pos=0,col=x;

	while(t_string[i])
	{
		pos = (y << 6) + x;

		switch(t_string[i])
		{
//			case 7:
//				// Bell (!)
//				break;
			case 9:
				// Horizontal Tab
				x = (x / 4 + 1) * 4;
				i++;
				break;
			case 10:
				// Carriage Return
				y++;
				x = col;
				i++;
				break;
			case 13:
				// Line Feed
				// x = col;
				break;
			default:
				BGMM[(0x1000 * bgmap) + pos] = ((u16)t_string[i] + 0x700) | (bplt << 14);
				if (x++ > 63)
				{
					x = col;
					y++;
				}
                		i++;
				break;
		}
	}
}

void bgmap_print(int bgmap, int col, int row, BYTE t_string[], int bplt)
/* Font map (0-255) must reside in the upper half of CharSeg3 */
{
	int i = 0;
	int pos = row * 64 + col;
	while(t_string[i])
	{
		BGMM[(0x1000 * bgmap) + pos + i] = (HWORD)t_string[i] + 0x700 + ((bplt & 0x03) << 14);
		i++;
	}
}

/***** BGMap Functions *****/
void vbSetBGMapCell(int n, int x, int y, HWORD header, int num)
{
	int i;
	for (i = 0; i < num; i++)
		BGMM[(0x1000 * n) + (y * 64) + x + i] = header;
}

void vbSetBGMap(int n, HWORD header)
{
	int i;
	for (i = 0; i < 4096; i++)
		BGMM[(0x1000 * n) + i] = header;
}

#define BGM_CSET(n,x,y,c)	BGMM[(0x1000 * n) + (y * 64) + x] = (BGMM[(0x1000 * n) + (y * 64) + x] & 0xF000) | (HWORD)c;
#define BGM_HSET(n,x,y,h)	BGMM[(0x1000 * n) + (y * 64) + x] = (BGMM[(0x1000 * n) + (y * 64) + x] & 0xDFFF) | (((HWORD)h << 13) & 0x2000);
#define BGM_VSET(n,x,y,v)	BGMM[(0x1000 * n) + (y * 64) + x] = (BGMM[(0x1000 * n) + (y * 64) + x] & 0xEFFF) | (((HWORD)v << 12) & 0x1000);
#define BGM_PALSET(n,x,y,pal)    BGMM[(0x1000 * n) + (y * 64) + x] = ((pal << 14) & 0xC000) | (0x1000 * n) + (BGMM[(0x1000 * n) + (y * 64) + x] & 0x3FFF);

/* "vbSetBGMap" header flags */
/* (OR these together to build an BGMap Header) */
#define	BGM_PAL0	0x0000
#define	BGM_PAL1	0x4000
#define	BGM_PAL2	0x8000
#define	BGM_PAL3	0xC000

#define	BGM_HFLIP	0x2000
#define	BGM_VFLIP	0x1000


#endif
