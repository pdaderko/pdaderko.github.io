// A Simon (Repeat what I do) type game for Virtual Boy by Pat Daderko (DogP)
// My first game for the Virtual Boy

#include <c:\gccvb\bin\libgccvb.h>
#include <c:\gccvb\bin\simonpics.h> // Unclutter code by putting pics in a different file

int difficulty = 15; // sets the number of repeats required to win
int firstboot = 1; // tells whether warning screen should be shown or not
int rand;	// random #

void BlinkUp()
{
	int parallax = -2; // required variable for negative parallax (old bug, but too lazy to go through and fix :P)
	while (VIP_REGS[XPSTTS] & XPBSYR);
	WAM[((30 << 5) >> 1)    ] = 0xC000;
	vbWaitFrame(15);
	while (VIP_REGS[XPSTTS] & XPBSYR);
	WAM[((30 << 5) >> 1)    ] = 0; // Clears the arrow for blink effect
	vbWaitFrame(10);
}

void BlinkDown()
{
	int parallax = -2; // required variable for negative parallax (old bug, but too lazy to go through and fix :P)
	while (VIP_REGS[XPSTTS] & XPBSYR);
	WAM[((29 << 5) >> 1)    ] = 0xC000;
	vbWaitFrame(15);
	while (VIP_REGS[XPSTTS] & XPBSYR);
	WAM[((29 << 5) >> 1)    ] = 0; // Clears the arrow for blink effect
	vbWaitFrame(10);
}

void BlinkLeft()
{
	int parallax = -2; // required variable for negative parallax (old bug, but too lazy to go through and fix :P)
	while (VIP_REGS[XPSTTS] & XPBSYR);
	WAM[((28 << 5) >> 1)    ] = 0xC000;
	vbWaitFrame(15);
	while (VIP_REGS[XPSTTS] & XPBSYR);
	WAM[((28 << 5) >> 1)    ] = 0; // Clears the arrow for blink effect
	vbWaitFrame(10);
}

void BlinkRight()
{
	int parallax = -2; // required variable for negative parallax (old bug, but too lazy to go through and fix :P)
	while (VIP_REGS[XPSTTS] & XPBSYR);
	WAM[((27 << 5) >> 1)    ] = 0xC000;
	vbWaitFrame(15);
	while (VIP_REGS[XPSTTS] & XPBSYR);
	WAM[((27 << 5) >> 1)    ] = 0; // Clears the arrow for blink effect
	vbWaitFrame(10);
}

void Win()
{
	int x = 0; // counter to move x
	int parallax = -3; // required variable for negative parallax (old bug, but too lazy to go through and fix :P)
	vbSetWorld(31, 0xC000, 0, 0, 0, 0, 0, 0, 0, 0); // Clear Screen
	vbSetWorld(30, 0xC000, 0, 0, 0, 0, 0, 0, 0, 0); // Clear Screen
	copymem((void*) CharSeg0, (void*) chWin, 129 * 16);   // Copy the chars to CharMap 0
	copymem((void*) BGMap(0), (void*) bgWin, 1024 * 16);  // Copy the char index to BGMap 0
	vbSetWorld(31, 0xC000, 0, 3, 0, 0, 0, 0, 384, 100);  // Show the Congratulations part of the Screen
	vbSetWorld(30, 0xC000, 0, parallax, 101, 0, 0, 101, 0, 224); // Show the Game Over message part of the screen
	vbWaitFrame(150);
	while (x < 384) // Counts to 384 and slowly chops the screen off horizontally
	{
		WAM[((31 << 5) >> 1) + 7] = 384 - x; // changes just the width
		WAM[((30 << 5) >> 1) + 7] = x; // changes just the width
		x++;
		vbWaitFrame(1);
	}
	vbDisplayHide();
}
void Wrong()
{
	int x = 0; // counter to change parallax
	int parallax = -2; // required variable for negative parallax (old bug, but too lazy to go through and fix :P)
	vbSetWorld(31, 0xC000, 0, 0, 0, 0, 0, 0, 0, 0); // Clear Screen
	vbSetWorld(30, 0xC000, 0, 0, 0, 0, 0, 0, 0, 0); // Clear Screen
	copymem((void*) CharSeg0, (void*) chWrong, 112 * 16); // Copy the chars to CharMap 0
	copymem((void*) BGMap(0), (void*) bgWrong, 1024 * 16); // Copy the char index to BGMap 0
	vbSetWorld(31, 0xC000, 0, 2, 0, 0, 0, 0, 384, 100); // Show the Wrong part of the Screen
	vbSetWorld(30, 0xC000, 0, x - 2, 101, 0, 0, 101, 384, 224); // Show the Game Over part of the Screen
	vbWaitFrame(150);
	while (x < 12) // Counts to 6 and changes the parallax
	{
		WAM[((31 << 5) >> 1) + 2] = 2 + x; // changes just the parallax
		WAM[((30 << 5) >> 1) + 2] = parallax - x;// changes just the parallax
		x++;
		vbWaitFrame(3);
	}
	vbWaitFrame(150);
	vbDisplayHide();
}

void DiffDisp(int difficulty)
{
	int parallax = -4; // required variable for negative parallax (old bug, but too lazy to go through and fix :P)
	if (difficulty == 10)
	{
		WAM[((30 << 5) >> 1) + 4] = 48; // Easy
		WAM[((30 << 5) >> 1) + 2] = 4;
	}

	if (difficulty == 15)
	{
		WAM[((30 << 5) >> 1) + 4] = 162; // Normal
		WAM[((30 << 5) >> 1) + 2] = 0;
	}

	if (difficulty == 20)
	{
		WAM[((30 << 5) >> 1) + 4] = 280; // Hard
		WAM[((30 << 5) >> 1) + 2] = parallax;
	}
}

int RandNum(int rand) // function that returns a random number between 1 and 4
{
	rand++;
	if (rand >= 5)
		rand = 1;
	return rand;
}

int main()
{
	int start = 0;	   // start button pressed
	int randomnext = 1;  // tells if it should do next random number
	int simonout[20];	// array of the simon to copy
	int simonin[20];	 // array of the players answers
	int turn = 0;		// defines what turn it is on
	int turnin = 0;	  // defines how many turns have been answered
	int playback = 16;   // counts which turn to play back
	int repeat = 16;	 // counts which turn to play back
	int parallax = -2;   // required variable for negative parallax (old bug, but too lazy to go through and fix :P)
	int startblink = 0;  // variable to make start blink
	int diffwait = 0;	// sets wait time for changing difficulty
	int timeoutcounter = 0;
	simonin[0] = 1;	  // sets simonin and simonout equal for "repeat - 1" condition
	simonout[0] = 1;	 // sets simonin and simonout equal for "repeat - 1" condition

	if (firstboot == 1) // gets a random number if it's the first time booting
	{
		rand = randseed();
		rand = (randnum(rand, 4) + 1);
	}
		
	copymem((void*) CharSeg0, (void*) chStart, 143 * 16); // Copy the chars to CharMap 0
	copymem((void*) BGMap(0), (void*) bgStart, 1024 * 16);  // Copy the char index to BGMap 0

	// vbSetWorld(HEADER, GX, GP, GY, MX, MP, MY, W, H)
	vbSetWorld(31, 0xC000, 0, 2, 0, 0, 0, 0, 384, 110); // Display Start Screen
	vbSetWorld(30, 0xC000, 152, 0, 184, 162, 0, 184, 80, 30); // Shows Normal
	vbSetWorld(29, 0xC000, 0, parallax, 123, 10, 0, 111, 384, 50); // Display Start Screen
	vbSetWorld(26, 0x0040, 0, 0, 0, 0, 0, 0, 0, 0); // Blank world and END bit set 
	
	DiffDisp(difficulty);	  // Calls a function that displays whatever difficulty is selected
	vbDisplayOn();			 // Turn the VB display on
	vbWaitFrame(10); // Fixes Difficulty Glitch
	vbFXFadeIn(2); // Diplay fade in
	firstboot = 0; // Tells that the game has been run
	vbWaitFrame(15); // Fixes restart flicker glitch

	while(start != 1)
	{
		if ((vbReadPad() & 0x100) && (difficulty < 20) && (diffwait >= 5)) // L pad right pressed
		{
			difficulty = difficulty + 5;
			diffwait = 0; // resets the wait time to keep the difficulty from changing to quickly
			DiffDisp(difficulty); // Calls a function that displays whatever difficulty is selected
		}
			
		else if ((vbReadPad() & 0x200) && (difficulty > 10) && (diffwait >= 5)) // L pad left pressed
		{
			difficulty = difficulty - 5;
			diffwait = 0; // resets the wait time to keep the difficulty from changing to quickly
			DiffDisp(difficulty); // Calls a function that displays whatever difficulty is selected
		}
		
		// Blinks press start without causing a wait (and in effect sluggish start)
		if (startblink == 0)
			WAM[((29 << 5) >> 1) + 7] = 384;
		if (startblink == 8)
			WAM[((29 << 5) >> 1) + 7] = 0; // Clear Screen
		vbWaitFrame(1);
		startblink++; // counts the variable that causes the press start to blink
		diffwait++; // counts the variable that forces a wait on difficulty setting
		if (startblink >= 16) // resets the startblink if 30
			startblink = 0;
		rand = RandNum(rand); // calls to get a random #
		if (vbReadPad() & 0x1000)	  // Start button pressed
			start = 1;
	}
	
	vbSetWorld(31, 0xC000, 0, 0, 0, 0, 0, 0, 0, 0); // Clear Screen
	vbSetWorld(30, 0xC000, 0, 0, 0, 0, 0, 0, 0, 0); // Clear Screen
	vbSetWorld(29, 0xC000, 0, 0, 0, 0, 0, 0, 0, 0); // Clear Screen
	copymem((void*) CharSeg0, (void*) chArrows, 120 * 16); // Copy the chars to CharMap 0
	copymem((void*) BGMap(0), (void*) bgArrows, 1024 * 16); // Copy the char index to BGMap 0
	vbSetWorld(31, 0xC000, 112, 0, 32, 0, 0, 0, 168, 168); // Display Board
	vbSetWorld(30, 0, 177, parallax, 54, 175, 0, 65, 96, 96); // Sets UP buttons
	vbSetWorld(29, 0, 177, parallax, 140, 175, 0, 65, 96, 96); // Sets DOWN buttons
	vbSetWorld(28, 0, 134, parallax, 97, 175, 0, 65, 96, 96); // Sets LEFT buttons
	vbSetWorld(27, 0, 220, parallax, 97, 175, 0, 65, 96, 96); // Sets RIGHT buttons
	   
	while(1) // Infinite loop to continue game forever
	{
		rand = RandNum(rand); // calls to get a random #
		while (playback <= turnin) // Plays back the previous blinks
		{
			rand = RandNum(rand); // calls to get a random #
			if (simonout[playback] == 1)
				BlinkUp();

			else if (simonout[playback] == 2)
				BlinkDown();
				
			else if (simonout[playback] == 3)
				BlinkLeft();

			else if (simonout[playback] == 4)
				BlinkRight();
			
			playback++;
		}
		
		rand = RandNum(rand); // calls to get a random #
		
		if (rand == 1 && randomnext == 1) // Blinks up if the random # is 1
		{
			BlinkUp();
			randomnext = 0; // makes it wait until a button is pressed (causing it to = 1 )
			turn++;
			simonout[turn] = 1;
		}
		else if (rand == 2 && randomnext == 1) // Blinks down if the random # is 2
		{
			BlinkDown();
			randomnext = 0; // makes it wait until a button is pressed (causing it to = 1 )
			turn++;
			simonout[turn] = 2;
		}
		else if (rand == 3 && randomnext == 1) // Blinks left if the random # is 3
		{
			BlinkLeft();
			randomnext = 0; // makes it wait until a button is pressed (causing it to = 1 )
			turn++;
			simonout[turn] = 3;
		}
		else if (rand == 4 && randomnext == 1) // Blinks right if the random # is 4
		{
			BlinkRight();
			randomnext = 0; // makes it wait until a button is pressed (causing it to = 1 )
			turn++;
			simonout[turn] = 4;
		}
	
		rand = RandNum(rand); // calls to get a random #
		
		while (repeat <= turnin)
		{
			rand = RandNum(rand); // calls to get a random #
			
			if (vbReadPad() & 0x100) // L pad right pressed
			{
				BlinkRight();
				simonin[repeat] = 4;
				repeat++;
				timeoutcounter = 0;
			}
			else if (vbReadPad() & 0x200) // L pad left pressed and makes sure button hasn't previously been pressed
			{
				BlinkLeft();
				simonin[repeat] = 3;
				repeat++;
				timeoutcounter = 0;
			}
			else if (vbReadPad() & 0x800) // L pad up pressed and makes sure button hasn't previously been pressed
			{
				BlinkUp();
				simonin[repeat] = 1;
				repeat++;
				timeoutcounter = 0;
			}
			else if (vbReadPad() & 0x400) // L pad down pressed and makes sure button hasn't previously been pressed
			{
				BlinkDown();
				simonin[repeat] = 2;
				repeat++;
				timeoutcounter = 0;
			}
			if (simonout[repeat - 1] != simonin[repeat - 1]) // Checks to make sure correct button is pressed
			{
				Wrong(); // Go to the wrong screen
				main(); // Resets game
			}
							
			rand = RandNum(rand); // calls to get a random #
		}

		rand = RandNum(rand); // calls to get a random #

		if ((vbReadPad() & 0x100) && (randomnext == 0))	  // L pad right pressed
		{
			BlinkRight();
			randomnext = 1; // allows it to go back to the top and repeat, and tells it not to do anything after this if
			simonin[turn] = 4;
			turnin++;
			timeoutcounter = 0;
			playback = 1; // tells it to play back the sequence back at the top
			repeat = 1; // resets the repeat counter so it starts repeating from the beginning
			if (simonout[turn] != simonin[turn])
			{
				Wrong(); // Go to the wrong screen
				main(); // Resets game
			}
			if (turn >= difficulty)
			{
				Win(); // Go to the win screen
				main(); // Resets game
			}
			vbWaitFrame(15);
		}
		
		else if ((vbReadPad() & 0x200) && (randomnext == 0)) // L pad left pressed
		{
			BlinkLeft();
			randomnext = 1; // allows it to go back to the top and repeat, and tells it not to do anything after this if
			simonin[turn] = 3;
			turnin++;
			timeoutcounter = 0;
			playback = 1; // tells it to play back the sequence back at the top
			repeat = 1; // resets the repeat counter so it starts repeating from the beginning
			if (simonout[turn] != simonin[turn])
			{
				Wrong(); // Go to the wrong screen
				main(); // Resets game
			}
			if (turn >= difficulty)
			{
				Win(); // Go to the win screen
				main(); // Resets game
			}
			vbWaitFrame(15);
		}
		
		else if ((vbReadPad() & 0x800) && (randomnext == 0)) // L pad up pressed
		{
			BlinkUp();
			randomnext = 1; // allows it to go back to the top and repeat, and tells it not to do anything after this if
			simonin[turn] = 1;
			turnin++;
			timeoutcounter = 0;
			playback = 1; // tells it to play back the sequence back at the top
			repeat = 1; // resets the repeat counter so it starts repeating from the beginning
			if (simonout[turn] != simonin[turn])
			{
				Wrong(); // Go to the wrong screen
				main(); // Resets game
			}
			if (turn >= difficulty)
			{
				Win(); // Go to the win screen
				main(); // Resets game
			}
			vbWaitFrame(15);
		}
		
		else if ((vbReadPad() & 0x400) && (randomnext == 0)) // L pad down pressed
		{
			BlinkDown();
			randomnext = 1; // allows it to go back to the top and repeat, and tells it not to do anything after this if
			simonin[turn] = 2;
			turnin++;
			timeoutcounter = 0;
			playback = 1; // tells it to play back the sequence back at the top
			repeat = 1; // resets the repeat counter so it starts repeating from the beginning
			if (simonout[turn] != simonin[turn])
			{
				Wrong(); // Go to the wrong screen
				main(); // Resets game
			}
			if (turn >= difficulty)
			{
				Win(); // Go to the win screen
				main(); // Resets game
			}
			vbWaitFrame(15);
		}
		
		rand = RandNum(rand); // calls to get a random #
		
		timeoutcounter++;
		vbWaitFrame(1);
		
		if (timeoutcounter == 75)
		{
			Wrong(); // Go to the wrong screen
			main(); // Resets game
		}
		
	}
	
	return 0;
}
