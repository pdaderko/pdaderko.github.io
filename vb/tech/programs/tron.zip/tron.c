//A Tron style game (2 player snake) by DogP (Pat Daderko)
//uses Direct Framebuffer writing with screen refreshing disabled and reading the framebuffers
//uses link port for a fast moving game

#include <c:\gccvb\bin\libgccvb.h>
#include <c:\gccvb\bin\tronpics.h>

// global vars for total wins/losses/ties/player
int player = 1;
int wins = 0;
int losses = 0;
int ties = 0;

int main ()
{	
	int x1; // starting x (This VB)
	int y1 = 111; // starting y (This VB)
	int x2; // starting x (Opponent)
	int y2 = 111; // starting y (Opponent)
	int direction1; // direction to move (This VB)
	int color1 = 2; // starting color (This VB)
	int parallax1 = -5; // starting parallax value (This VB)
	int direction2; // direction to move (Opponent)
	int color2 = 2; // starting color (Opponent)
	int parallax2 = -5; // starting parallax value (Opponent)
	int count; // counter used for pauses
	int turn; // determines who moves "first"
	int prevdir; // previous direction so changing parallax takes one "move"
	int paracount; // counter used for changing parallax
	int read; // handshake variable
	int startpress = 0; // tells if start has been pressed or not

	// disable interrupts to allow sends without affecting unready receiver
	HW_REGS[CCSR] = 0xFF;
	HW_REGS[CCR] = 0x80;

	copymem((void*) CharSeg0, (void*) chTronStart, 104 * 16); // Copy the chars to CharMap 0
	copymem((void*) BGMap(0), (void*) bgTronStart, 1024 * 16);  // Copy the char index to BGMap 0
	vbSetWorld(31, 0xC000, 0, 0, 0, 0, 0, 0, 384, 90); // set the Tron word
	vbSetWorld(30, 0xC000, 0, -8, 90, 0, 0, 90, 384, 60); // set the VB
	vbSetWorld(29, 0xC000, 0, 0, 150, 0, 0, 150, 192, 70); // set the 1
	vbSetWorld(28, 0xC000, 192, 0, 150, 192, 0, 150, 192, 70); // set the 2
	vbSetWorld(27, 0x0040, 0, 0, 0, 0, 0, 0, 0, 0); // Blank world and END bit set 
	
	// sets the parallax for the correct player before showing the display
	if (player == 1)
	{
		WAM[((29 << 5) >> 1) + 2] = -5;
    		WAM[((28 << 5) >> 1) + 2] = 5;
    	}
	if (player == 2)
	{
		WAM[((29 << 5) >> 1) + 2] = 5;
    		WAM[((28 << 5) >> 1) + 2] = -5;
	}
	
	vbDisplayOn(); // turns the display on
	vbDisplayShow(); // shows the display
	
	vbWaitFrame(5); // pause
	
	// stays on startup screen until either player presses start
	while ((HW_REGS[CDRR] != 0x44) && (HW_REGS[CDRR] != 0x88) && (startpress != 1))
	{
		HW_REGS[CCR] = 0x94; // start transfer as remote
		while (HW_REGS[CCR] & 2)
		{
			// pressed right to change player from 1 to 2
			if ((vbReadPad() & K_LR) && (player == 1))
			{
				player = 2;
				// makes parallax slowly change
				for (paracount = -5; paracount <= 5; paracount++)
				{
					WAM[((29 << 5) >> 1) + 2] ++;
					WAM[((28 << 5) >> 1) + 2] --;
					for (count = 0; count < 8000; count++); // pause
				}
			}
			// pressed left to change player from 2 to 1
			if ((vbReadPad() & K_LL) && (player == 2))
			{
				player = 1;
				// makes parallax slowly change
				for (paracount = -5; paracount <= 5; paracount++)
				{
					WAM[((28 << 5) >> 1) + 2] ++;
					WAM[((29 << 5) >> 1) + 2] --;
					for (count = 0; count < 8000; count++); // pause
				}
			}
			// pressed start to select player
			if (vbReadPad() & K_STA)
			{
				startpress = 1;
				if (player == 1)
					HW_REGS[CDTR] = 0x44; // data for player 1
				if (player == 2)
					HW_REGS[CDTR] = 0x88; // data for player 2
				HW_REGS[CCR] = 0x84; // start transfer as master
				while (HW_REGS[CCR] & 2); // wait for transfer to finish
				break;
			}
		}
	
		// sets to the opposite of the other player if the other person pressed start first
		if ((HW_REGS[CDRR] == 0x44) && (player == 1))
		{
			player = 2;
			// makes parallax slowly change
			for (paracount = -5; paracount <= 5; paracount++)
			{
				WAM[((29 << 5) >> 1) + 2] ++;
				WAM[((28 << 5) >> 1) + 2] --;
				for (count = 0; count < 8000; count++); // pause
			}
		}
		if ((HW_REGS[CDRR] == 0x88) && (player == 2))
		{
			player = 1;
			// makes parallax slowly change
			for (paracount = -5; paracount <= 5; paracount++)
			{
				WAM[((28 << 5) >> 1) + 2] ++;
				WAM[((29 << 5) >> 1) + 2] --;
				for (count = 0; count < 8000; count++); // pause
			}
		}
	}
	
	vbSetWorld(31, 0x0040, 0, 0, 0, 0, 0, 0, 0, 0); // Blank world and END bit set to cancel out the rest of the worlds (Only framebuffers used beyond this point)
	
	// initializes data for players
	if (player == 1)
	{
		x1 = 50;
		x2 = 333;
		direction1 = 3;
		prevdir = direction1;
		turn = 1;
	}
	if (player == 2)
	{
		x1 = 333;
		x2 = 50;
		direction1 = 2;
		prevdir = direction1;
		turn = 0;
	}
	
	for (count = 0; count < 200000; count++); // pauses to make sure other VB is done with read register before continuing
	
	// Sends data back and forth as a type of "handshake" to tell each other that they're ready to start the game
	HW_REGS[CDTR] = 0x55; // first set of data
	HW_REGS[CCR] = 0x84; // start transfer as master
	while (HW_REGS[CCR] & 2); // wait for transfer to finish
	
	HW_REGS[CCR] = 0x94; // start transfer as remote
	while (HW_REGS[CCR] & 2); // wait for transfer to finish
	read = HW_REGS[CDRR]; // checks which set of data received (to tell which system started first)
	
	if (read == 0x55)
	{
		HW_REGS[CDTR] = 0xAA; // second set of data
		HW_REGS[CCR] = 0x84; // start transfer as master
		while (HW_REGS[CCR] & 2); // wait for transfer to finish
	}
	
	for (count = 0; count < 100000; count++); // pauses to make sure screen clears before starting the game
	
	if (player == 1)
		for (count = 0; count < 200000; count++); // pauses to ensure receiver is ready
	
	VIP_REGS[XPCTRL] = VIP_REGS[XPSTTS] | XPEN; // sets the XPEN bit to make sure screen clears
	while (!(VIP_REGS[XPSTTS] & XPBSY1)); // makes sure to freeze screen on framebuffer 0
	VIP_REGS[XPCTRL] = VIP_REGS[XPSTTS] & ~XPEN; // turn off screen refreshing so once a dot is drawn it stays there until refreshed again (start pressed)

	// Draws the walls for the play field
	buffvln(10, 5, 214, 2, -5);
	buffhln(10, 5, 364, 2, -5);
	buffvln(374, 5, 214, 2, -5);
	buffhln(10, 219, 364, 2, -5);
	buffvln(10, 5, 214, 1, 5);
	buffhln(10, 5, 364, 1, 5);
	buffvln(374, 5, 214, 1, 5);
	buffhln(10, 219, 364, 1, 5);

	while (1)
	{
		if (turn == 1)
		{
			// changes the direction if button is pushed
			if (vbReadPad() & K_LU)
			{
				direction1 = 0; // moves dot up
				prevdir = direction1;
			}
			else if (vbReadPad() & K_LD)
			{
				direction1 = 1; // moves dot down
				prevdir = direction1;
			}
			else if (vbReadPad() & K_LL)
			{
				direction1 = 2; // moves dot left
				prevdir = direction1;
			}
			else if (vbReadPad() & K_LR)
			{
				direction1 = 3; // moves dot right
				prevdir = direction1;
			}
	
			else if ((vbReadPad() & K_LT) && (parallax1 == -5))
			{
				prevdir = direction1;
				direction1 = 4; // moves dot to background
			}
			else if ((vbReadPad() & K_RT) && (parallax1 == 5))
			{
				prevdir = direction1;
				direction1 = 5; // moves dot to foreground
			}
			
			// tells which way the person wants to move
			if (direction1 == 0)
			{
				y1--;
				for (count = 0; count < 5000; count++); // pause
			}
			else if (direction1 == 1)
			{
				y1++;
				for (count = 0; count < 5000; count++); // pause
			}
			else if (direction1 == 2)
			{
				x1--;
				for (count = 0; count < 5000; count++); // pause
			}
			else if (direction1 == 3)
			{
				x1++;
				for (count = 0; count < 5000; count++); // pause
			}
			else if (direction1 == 4)
			{
				color1 = 1;
				parallax1 = 5;
				for (count = 0; count < 5000; count++); // pause
			}
			else if (direction1 == 5)
			{
				color1 = 2;
				parallax1 = -5;
				for (count = 0; count < 5000; count++); // pause
			}
			
			//reads the pixel to make sure the pixel moving to isn't already occupied, and if it is, ends the game
			if (readpixel(x1, y1, parallax1) & color1)
			{
				buffhln(x1, y1, 0, color1, parallax1); // draws to show the crash
				HW_REGS[CDTR] = direction1; // puts direction1 in send register
				HW_REGS[CCR] = 0x84; // start transfer as master
				while (HW_REGS[CCR] & 2); // wait for transfer to finish
				main(); // resets
			}
			
			HW_REGS[CDTR] = direction1; // puts direction1 in send register
			HW_REGS[CCR] = 0x84; // start transfer as master
			while (HW_REGS[CCR] & 2); // wait for transfer to finish
			
			buffhln(x1, y1, 0, color1, parallax1); // draws pixel
			
			direction1 = prevdir; // makes dot continue moving in previous direction if parallax is changed
			turn = 0; // makes it other player's turn
		}
		
		HW_REGS[CCR] = 0x94; // start transfer as remote
		while (HW_REGS[CCR] & 2); // wait for transfer to finish (data to be sent)
		direction2 = HW_REGS[CDRR]; // makes direction2 the data received
		
		// tells which way the other person wants to move
		if (direction2 == 0)
		{
			y2--;
			for (count = 0; count < 5000; count++); // pause
		}
		else if (direction2 == 1)
		{
			y2++;
			for (count = 0; count < 5000; count++); // pause
		}
		else if (direction2 == 2)
		{
			x2--;
			for (count = 0; count < 5000; count++); // pause
		}
		else if (direction2 == 3)
		{
			x2++;
			for (count = 0; count < 5000; count++); // pause
		}
		else if (direction2 == 4)
		{
			color2 = 1;
			parallax2 = 5;
		}
		else if (direction2 == 5)
		{
			color2 = 2;
			parallax2 = -5;
		}
		
		//reads the pixel to make sure the pixel moving to isn't already occupied, and if it is, ends the game
		if (readpixel(x2, y2, parallax2) & color2)
		{
			buffhln(x2, y2, 0, color2, parallax2); // draws to show the crash
			main(); // resets
		}
		
		buffhln(x2, y2, 0, color2, parallax2); // draws pixel
		
		turn = 1; // makes it this VB's turn
	}
	return 0;
}
