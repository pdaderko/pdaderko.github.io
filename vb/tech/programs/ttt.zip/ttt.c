//A TicTacToe game for Virtual Boy by Pat Daderko (DogP)
//uses link port

#include <c:\gccvb\bin\libgccvb.h>
#include <c:\gccvb\bin\tttpics.h> // Unclutter code by putting pics in a different file

// global vars for total wins/losses/ties/player
int wins = 0;
int losses = 0;
int ties = 0;
int youxo = 1;

int realVBSpeed = 1;

// Clears all the worlds at the end of the game
void ClearWorlds()
{
	int x;
	for (x = 30; x >= 19; x--)
	{
		while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
		WORLD_HEAD(x,0); // hides the world
	}
}

// Clears any world that hasn't been selected
void clear(int addpos)
{
	if (!(addpos & 0x0001))
	{
		while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
		WORLD_HEAD(30,0); // hides the world
	}
	if (!(addpos & 0x0002))
	{
		while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
		WORLD_HEAD(29,0); // hides the world
	}
	if (!(addpos & 0x0004))
	{
		while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
		WORLD_HEAD(28,0); // hides the world
	}
	if (!(addpos & 0x0008))
	{
		while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
		WORLD_HEAD(27,0); // hides the world
	}
	if (!(addpos & 0x0010))
	{
		while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
		WORLD_HEAD(26,0); // hides the world
	}
	if (!(addpos & 0x0020))
	{
		while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
		WORLD_HEAD(25,0); // hides the world
	}
	if (!(addpos & 0x0040))
	{
		while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
		WORLD_HEAD(24,0); // hides the world
	}
	if (!(addpos & 0x0080))
	{
		while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
		WORLD_HEAD(23,0); // hides the world
	}
	if (!(addpos & 0x0100))
	{
		while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
		WORLD_HEAD(22,0); // hides the world
	}
}

int main()
{
	int pos; // position of the cursor (binary number shifted 1-9 to make easy to tell win/loss)
	int sendpos = 0; // position to send to the other VB across the link (1-9)
	int addpos = 0; // all positions added together to tell whether space is occupied
	int addyou = 0; // all your positions added together to tell whether you have a line
	int addthem = 0; // all their positions added together to tell whether they have a line 
	int turnover; // tells whether the turn is over
	int otherpos = 0; // the position read from the other VB
	int themxo; // the other player's type (X or O)
	int paracount; // counter used for smooth parallax change
	int gameover = 0; // variable to tell that the game is over (lets it do animations and reset game later in program)
	int read; // handshake variable
	int startpress = 0; // tells if start has been pressed or not
	
	// disable interrupts to allow sends without affecting unready receiver
	HW_REGS[CCSR] = 0xFF;
	HW_REGS[CCR] = 0x80;
	
	copymem((void*) CharSeg0, (void*) chTttStart, 98 * 16); // Copy the chars to CharMap 0
    	copymem((void*) BGMap(0), (void*) bgTttStart, 1024 * 16);  // Copy the char index to BGMap 0
    	
    	// vbSetWorld(HEADER, GX, GP, GY, MX, MP, MY, W, H)
	vbSetWorld(31, 0xC000, 101, 0, 0, 0, 0, 0, 182, 182);
	vbSetWorld(30, 0, 111, -5, 10, 12, 0, 181, 36, 36);
	vbSetWorld(29, 0, 174, -5, 10, 194, 0, 11, 36, 36);
	vbSetWorld(28, 0, 235, -5, 10, 224, 0, 11, 36, 36);
	vbSetWorld(27, 0, 111, -5, 73, 12, 0, 181, 36, 36);
	vbSetWorld(26, 0, 174, -5, 73, 194, 0, 78, 36, 36);
	vbSetWorld(25, 0, 235, -5, 73, 224, 0, 78, 36, 36);
	vbSetWorld(24, 0, 111, -5, 134, 12, 0, 181, 36, 36);
	vbSetWorld(23, 0, 174, -5, 134, 194, 0, 140, 36, 36);
	vbSetWorld(22, 0, 235, -5, 134, 224, 0, 140, 36, 36);
	vbSetWorld(21, 0xC000, 131, 0, 190, 76, 0, 181, 36, 36);
	vbSetWorld(20, 0xC000, 220, 0, 190, 136, 0, 181, 36, 36);
	vbSetWorld(19, 0x0040, 0, 0, 0, 0, 0, 0, 0, 0); // Blank world and END bit set
    	
    	// sets the parallax for the correct player before showing the display
    	if (youxo == 0)
    	{
    		WAM[((20 << 5) >> 1) + 2] = -6;
    		WAM[((21 << 5) >> 1) + 2] = 0;
    		themxo = 1;
    		turnover = 1;
    	}
    	if (youxo == 1)
    	{
    		WAM[((20 << 5) >> 1) + 2] = 0;
    		WAM[((21 << 5) >> 1) + 2] = -6;
    		themxo = 0;
    		turnover = 0;
    	}
    	
    	vbDisplayOn(); // Turn the VB display on
    	
    	vbWaitFrame(30*realVBSpeed); // gives it time to change the world to prevent glitches
    	
    	vbDisplayShow(); // Shows the display
	
	// the startup animation of the letters coming up
	while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
	WORLD_HEAD(30,0xC000);
	vbWaitFrame(15*realVBSpeed);
	while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
	WORLD_HEAD(26,0xC000);
	vbWaitFrame(15*realVBSpeed);
	while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
	WORLD_HEAD(29,0xC000);
	vbWaitFrame(15*realVBSpeed);
	while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
	WORLD_HEAD(28,0xC000);
	vbWaitFrame(15*realVBSpeed);
	while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
	WORLD_HEAD(22,0xC000);
	vbWaitFrame(15*realVBSpeed);
	while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
	WORLD_HEAD(25,0xC000);
	vbWaitFrame(15*realVBSpeed);
	while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
	WORLD_HEAD(24,0xC000);
	vbWaitFrame(15*realVBSpeed);
	while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
	WORLD_HEAD(23,0xC000);
	vbWaitFrame(15*realVBSpeed);
	while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
	WORLD_HEAD(27,0xC000);
	vbWaitFrame(15*realVBSpeed);
	
	// parallax change animation of the startup
	for (paracount = 0; paracount < 5; paracount++)
	{
		WAM[((30 << 5) >> 1) + 2] --;
		WAM[((29 << 5) >> 1) + 2] ++;
		WAM[((28 << 5) >> 1) + 2] ++;
		WAM[((27 << 5) >> 1) + 2] --;
		WAM[((26 << 5) >> 1) + 2] ++;
		WAM[((25 << 5) >> 1) + 2] ++;
		WAM[((24 << 5) >> 1) + 2] --;
		WAM[((23 << 5) >> 1) + 2] ++;
		WAM[((22 << 5) >> 1) + 2] ++;
		vbWaitFrame(3*realVBSpeed);
	}
	
	// stays on startup screen until either player presses start
	while ((HW_REGS[CDRR] != 0x44) && (HW_REGS[CDRR] != 0x88) && (startpress != 1))
	{
		HW_REGS[CCR] = 0x94; // start transfer as remote
		while (HW_REGS[CCR] & 2)
		{
			// pressed left to change player from O to X
			if ((vbReadPad() & K_LL) && (youxo == 0))
			{
				youxo = 1;
				themxo = 0;
				turnover = 0;
				for (paracount = 0; paracount < 6; paracount++)
				{
					WAM[((20 << 5) >> 1) + 2] ++;
					WAM[((21 << 5) >> 1) + 2] --;
					vbWaitFrame(1*realVBSpeed);
				}
			}
			// pressed right to change player from X to O
			if ((vbReadPad() & K_LR) && (youxo == 1))
			{
				youxo = 0;
				themxo = 1;
				turnover = 1;
				for (paracount = 0; paracount < 6; paracount++)
				{
					WAM[((20 << 5) >> 1) + 2] --;
					WAM[((21 << 5) >> 1) + 2] ++;
					vbWaitFrame(1*realVBSpeed);
				}
			}
			// pressed start to select player
			if (vbReadPad() & K_STA)
			{
				startpress = 1;
				if (youxo == 0)
					HW_REGS[CDTR] = 0x44; // data for youxo 0
				if (youxo == 1)
					HW_REGS[CDTR] = 0x88; // data for youxo 1
				HW_REGS[CCR] = 0x84; // start transfer as master
				while (HW_REGS[CCR] & 2); // wait for transfer to finish
				break;
			}
		}
		
		// sets to the opposite of the other player if the other person pressed start first
		if ((HW_REGS[CDRR] == 0x44) && (youxo == 0))
		{
			youxo = 1;
			themxo = 0;
			turnover = 0;
			for (paracount = 0; paracount < 6; paracount++)
			{
				WAM[((20 << 5) >> 1) + 2] ++;
				WAM[((21 << 5) >> 1) + 2] --;
				vbWaitFrame(1*realVBSpeed);
			}
		}
		if ((HW_REGS[CDRR] == 0x88) && (youxo == 1))
		{
			youxo = 0;
			themxo = 1;
			turnover = 1;
			for (paracount = 0; paracount < 6; paracount++)
			{
				WAM[((20 << 5) >> 1) + 2] --;
				WAM[((21 << 5) >> 1) + 2] ++;
				vbWaitFrame(1*realVBSpeed);
			}
		}
	}
	
	vbWaitFrame(30*realVBSpeed); // wait to make sure other VB is done with read register before continuing
	
	vbDisplayHide(); // hide the display to do a memory copy and set up the worlds
	
	copymem((void*) CharSeg0, (void*) chTtt, 105 * 16); // Copy the chars to CharMap 0
    	copymem((void*) BGMap(0), (void*) bgTtt, 1024 * 16);  // Copy the char index to BGMap 0
	
	// Sends data back and forth as a type of "handshake" to tell each other that they're ready to start the game
	HW_REGS[CDTR] = 0x55; // first set of data
	HW_REGS[CCR] = 0x84; // start transfer as master
	while (HW_REGS[CCR] & 2); // wait for transfer to finish
	
	HW_REGS[CCR] = 0x94; // start transfer as remote
	while (HW_REGS[CCR] & 2); // wait for transfer to finish
	read = HW_REGS[CDRR]; // checks which set of data received (to tell which system started first)
	
	if (read == 0x55)
	{
		HW_REGS[CDTR] = 0xAA; // second set of data
		HW_REGS[CCR] = 0x84; // start transfer as master
		while (HW_REGS[CCR] & 2); // wait for transfer to finish
	}
	
	// pauses to ensure receiver is ready
	if (youxo == 1)
		vbWaitFrame(10*realVBSpeed);
	
	// vbSetWorld(HEADER, GX, GP, GY, MX, MP, MY, W, H)
	vbSetWorld(31, 0xC000, 40, 0, 0, 0, 0, 0, 224, 224);
	vbSetWorld(30, 0, 40, -5, 5, (youxo * 80), 0, 225, 68, 58);
	vbSetWorld(29, 0, 120, -5, 5, (youxo * 80), 0, 225, 68, 58);
	vbSetWorld(28, 0, 200, -5, 5, (youxo * 80), 0, 225, 68, 58);
	vbSetWorld(27, 0, 40, -5, 85, (youxo * 80), 0, 225, 68, 58);
	vbSetWorld(26, 0, 120, -5, 85, (youxo * 80), 0, 225, 68, 58);
	vbSetWorld(25, 0, 200, -5, 85, (youxo * 80), 0, 225, 68, 58);
	vbSetWorld(24, 0, 40, -5, 165, (youxo * 80), 0, 225, 68, 58);
	vbSetWorld(23, 0, 120, -5, 165, (youxo * 80), 0, 225, 68, 58);
	vbSetWorld(22, 0, 200, -5, 165, (youxo * 80), 0, 225, 68, 58);
	vbSetWorld(21, 0x0040, -5, 0, 0, 0, 0, 0, 0, 0); // Blank world and END bit set

	// shows the X in the middle if the player is X
	if (youxo == 1)
		WORLD_HEAD(26,0xC000);
	
	vbWaitFrame(15*realVBSpeed); // gives it time to change the world to prevent glitches
	
	vbDisplayShow();
	
	while(1)
	{
		// moves the X or O to the position pointed to on the D-Pad and selects it by pressing A
		while(turnover == 0)
		{
			if ((!((vbReadPad() | 3) ^ (0x0900 | 3))) && (!(addpos & 0x0004)))
			{
				pos = 0x0004;
				sendpos = 0x03;
				clear(addpos);
				while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
				WORLD_HEAD(28,0xC000); // shows the world
				while (!((vbReadPad() | 3) ^ (0x0900 | 3)));
			}
			else if ((!((vbReadPad() | 3) ^ (0x0500 | 3))) && (!(addpos & 0x0100)))
			{
				pos = 0x0100;
				sendpos = 0x09;
				clear(addpos);
				while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
				WORLD_HEAD(22,0xC000); // shows the world
				while (!((vbReadPad() | 3) ^ (0x0500 | 3)));
			}
			else if ((!((vbReadPad() | 3) ^ (0x0600 | 3))) && (!(addpos & 0x0040)))
			{
				pos = 0x0040;
				sendpos = 0x07;
				clear(addpos);
				while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
				WORLD_HEAD(24,0xC000); // shows the world
				while (!((vbReadPad() | 3) ^ (0x0600 | 3)));
			}
			else if ((!((vbReadPad() | 3) ^ (0x0A00 | 3))) && (!(addpos & 0x0001)))
			{
				pos = 0x0001;
				sendpos = 0x01;
				clear(addpos);
				while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
				WORLD_HEAD(30,0xC000); // shows the world
				while (!((vbReadPad() | 3) ^ (0x0A00 | 3)));
			}
			else if ((!((vbReadPad() | 3) ^ (K_LU | 3))) && (!(addpos & 0x0002)))
			{
				pos = 0x0002;
				sendpos = 0x02;
				clear(addpos);
				while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
				WORLD_HEAD(29,0xC000); // shows the world
				while (!((vbReadPad() | 3) ^ (K_LU | 3)));
			}
			else if ((!((vbReadPad() | 3) ^ (K_LR | 3))) && (!(addpos & 0x0020)))
			{
				pos = 0x0020;
				sendpos = 0x06;
				clear(addpos);
				while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
				WORLD_HEAD(25,0xC000); // shows the world
				while (!((vbReadPad() | 3) ^ (K_LR | 3)));
			}		
			else if ((!((vbReadPad() | 3) ^ (K_LD | 3))) && (!(addpos & 0x0080)))
			{
				pos = 0x0080;
				sendpos = 0x08;
				clear(addpos);
				while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
				WORLD_HEAD(23,0xC000); // shows the world
				while (!((vbReadPad() | 3) ^ (K_LD | 3)));
			}		
			else if ((!((vbReadPad() | 3) ^ (K_LL | 3))) && (!(addpos & 0x0008)))
			{
				pos = 0x0008;
				sendpos = 0x04;
				clear(addpos);
				while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
				WORLD_HEAD(27,0xC000); // shows the world
				while (!((vbReadPad() | 3) ^ (K_LL | 3)));
			}		
			else if ((pos != 0x0010) && (!(addpos & 0x0010)))
			{
				pos = 0x0010;
				sendpos = 0x05;
				clear(addpos);
				while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
				WORLD_HEAD(26,0xC000); // shows the world
			}
			if ((vbReadPad() & K_A) && (pos != 0x0000))
			{
				turnover = 1;
				addyou += pos;
				addpos += pos;
				clear(addpos);
				pos = 0x0000;
				HW_REGS[CDTR] = sendpos; // puts the postion to send in send register
				HW_REGS[CCR] = 0x84; // start transfer as master
				while (HW_REGS[CCR] & 2); // wait for transfer to finish
				
				// ends the game if you have a line
				if ((addyou & 0x0007) == 0x0007)
				{
					wins++;
					gameover = 1;
					for (paracount = 0; paracount < 5; paracount++)
					{
						WAM[((30 << 5) >> 1) + 2] --;
						WAM[((29 << 5) >> 1) + 2] --;
						WAM[((28 << 5) >> 1) + 2] --;
						WAM[((27 << 5) >> 1) + 2] ++;
						WAM[((26 << 5) >> 1) + 2] ++;
						WAM[((25 << 5) >> 1) + 2] ++;
						WAM[((24 << 5) >> 1) + 2] ++;
						WAM[((23 << 5) >> 1) + 2] ++;
						WAM[((22 << 5) >> 1) + 2] ++;
						vbWaitFrame(5*realVBSpeed);
					}
				}
				if ((addyou & 0x0038) == 0x0038)
				{
					wins++;
					gameover = 1;
					for (paracount = 0; paracount < 5; paracount++)
					{
						WAM[((30 << 5) >> 1) + 2] ++;
						WAM[((29 << 5) >> 1) + 2] ++;
						WAM[((28 << 5) >> 1) + 2] ++;
						WAM[((27 << 5) >> 1) + 2] --;
						WAM[((26 << 5) >> 1) + 2] --;
						WAM[((25 << 5) >> 1) + 2] --;
						WAM[((24 << 5) >> 1) + 2] ++;
						WAM[((23 << 5) >> 1) + 2] ++;
						WAM[((22 << 5) >> 1) + 2] ++;
						vbWaitFrame(5*realVBSpeed);
					}
				}
				if ((addyou & 0x01C0) == 0x01C0)
				{
					wins++;
					gameover = 1;
					for (paracount = 0; paracount < 5; paracount++)
					{
						WAM[((30 << 5) >> 1) + 2] ++;
						WAM[((29 << 5) >> 1) + 2] ++;
						WAM[((28 << 5) >> 1) + 2] ++;
						WAM[((27 << 5) >> 1) + 2] ++;
						WAM[((26 << 5) >> 1) + 2] ++;
						WAM[((25 << 5) >> 1) + 2] ++;
						WAM[((24 << 5) >> 1) + 2] --;
						WAM[((23 << 5) >> 1) + 2] --;
						WAM[((22 << 5) >> 1) + 2] --;
						vbWaitFrame(5*realVBSpeed);
					}
				}
				if ((addyou & 0x0049) == 0x0049)
				{
					wins++;
					gameover = 1;
					for (paracount = 0; paracount < 5; paracount++)
					{
						WAM[((30 << 5) >> 1) + 2] --;
						WAM[((29 << 5) >> 1) + 2] ++;
						WAM[((28 << 5) >> 1) + 2] ++;
						WAM[((27 << 5) >> 1) + 2] --;
						WAM[((26 << 5) >> 1) + 2] ++;
						WAM[((25 << 5) >> 1) + 2] ++;
						WAM[((24 << 5) >> 1) + 2] --;
						WAM[((23 << 5) >> 1) + 2] ++;
						WAM[((22 << 5) >> 1) + 2] ++;
						vbWaitFrame(5*realVBSpeed);
					}
				}
				if ((addyou & 0x0092) == 0x0092)
				{
					wins++;
					gameover = 1;
					for (paracount = 0; paracount < 5; paracount++)
					{
						WAM[((30 << 5) >> 1) + 2] ++;
						WAM[((29 << 5) >> 1) + 2] --;
						WAM[((28 << 5) >> 1) + 2] ++;
						WAM[((27 << 5) >> 1) + 2] ++;
						WAM[((26 << 5) >> 1) + 2] --;
						WAM[((25 << 5) >> 1) + 2] ++;
						WAM[((24 << 5) >> 1) + 2] ++;
						WAM[((23 << 5) >> 1) + 2] --;
						WAM[((22 << 5) >> 1) + 2] ++;
						vbWaitFrame(5*realVBSpeed);
					}
				}
				if ((addyou & 0x0124) == 0x0124)
				{
					wins++;
					gameover = 1;
					for (paracount = 0; paracount < 5; paracount++)
					{
						WAM[((30 << 5) >> 1) + 2] ++;
						WAM[((29 << 5) >> 1) + 2] ++;
						WAM[((28 << 5) >> 1) + 2] --;
						WAM[((27 << 5) >> 1) + 2] ++;
						WAM[((26 << 5) >> 1) + 2] ++;
						WAM[((25 << 5) >> 1) + 2] --;
						WAM[((24 << 5) >> 1) + 2] ++;
						WAM[((23 << 5) >> 1) + 2] ++;
						WAM[((22 << 5) >> 1) + 2] --;
						vbWaitFrame(5*realVBSpeed);
					}
				}
				if ((addyou & 0x0111) == 0x0111)
				{
					wins++;
					gameover = 1;
					for (paracount = 0; paracount < 5; paracount++)
					{
						WAM[((30 << 5) >> 1) + 2] --;
						WAM[((29 << 5) >> 1) + 2] ++;
						WAM[((28 << 5) >> 1) + 2] ++;
						WAM[((27 << 5) >> 1) + 2] ++;
						WAM[((26 << 5) >> 1) + 2] --;
						WAM[((25 << 5) >> 1) + 2] ++;
						WAM[((24 << 5) >> 1) + 2] ++;
						WAM[((23 << 5) >> 1) + 2] ++;
						WAM[((22 << 5) >> 1) + 2] --;
						vbWaitFrame(5*realVBSpeed);
					}
				}
				if ((addyou & 0x0054) == 0x0054)
				{
					wins++;
					gameover = 1;
					for (paracount = 0; paracount < 5; paracount++)
					{
						WAM[((30 << 5) >> 1) + 2] ++;
						WAM[((29 << 5) >> 1) + 2] ++;
						WAM[((28 << 5) >> 1) + 2] --;
						WAM[((27 << 5) >> 1) + 2] ++;
						WAM[((26 << 5) >> 1) + 2] --;
						WAM[((25 << 5) >> 1) + 2] ++;
						WAM[((24 << 5) >> 1) + 2] --;
						WAM[((23 << 5) >> 1) + 2] ++;
						WAM[((22 << 5) >> 1) + 2] ++;
						vbWaitFrame(5*realVBSpeed);
					}
				}
				
				if (gameover == 1)
				{
					vbWaitFrame(30*realVBSpeed);
					vbDisplayHide();
					ClearWorlds();
					main();
				}
				
				if (addpos == 0x01FF) // board completely filled and no winner
				{
					ties++;
					for (paracount = 0; paracount < 5; paracount++)
					{
						WAM[((30 << 5) >> 1) + 2] ++;
						WAM[((29 << 5) >> 1) + 2] ++;
						WAM[((28 << 5) >> 1) + 2] ++;
						WAM[((27 << 5) >> 1) + 2] ++;
						WAM[((26 << 5) >> 1) + 2] ++;
						WAM[((25 << 5) >> 1) + 2] ++;
						WAM[((24 << 5) >> 1) + 2] ++;
						WAM[((23 << 5) >> 1) + 2] ++;
						WAM[((22 << 5) >> 1) + 2] ++;
						vbWaitFrame(5*realVBSpeed);
					}
					vbWaitFrame(70*realVBSpeed);
					vbDisplayHide();
					ClearWorlds();
					main();
				}
			}
		}
		HW_REGS[CCR] = 0x94; // start transfer as remote
		while (HW_REGS[CCR] & 2); // wait for transfer to finish
		otherpos = HW_REGS[CDRR]; // reads the position of the other player

		// moves the X or O to the position sent by the other VB
		if (otherpos == 1)
		{
			WAM[((30 << 5) >> 1) + 4] = (themxo * 80);
			while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
			WORLD_HEAD(30,0xC000); // shows the world
			addthem += 0x0001;
			addpos += 0x0001;
		}
		if (otherpos == 2)
		{
			WAM[((29 << 5) >> 1) + 4] = (themxo * 80);
			while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
			WORLD_HEAD(29,0xC000); // shows the world
			addthem += 0x0002;
			addpos += 0x0002;
		}
		if (otherpos == 3)
		{
			WAM[((28 << 5) >> 1) + 4] = (themxo * 80);
			while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
			WORLD_HEAD(28,0xC000); // shows the world
			addthem += 0x0004;
			addpos += 0x0004;
		}
		if (otherpos == 4)
		{
			WAM[((27 << 5) >> 1) + 4] = (themxo * 80);
			while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
			WORLD_HEAD(27,0xC000); // shows the world
			addthem += 0x0008;
			addpos += 0x0008;
		}
		if (otherpos == 5)
		{
			WAM[((26 << 5) >> 1) + 4] = (themxo * 80);
			while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
			WORLD_HEAD(26,0xC000); // shows the world
			addthem += 0x0010;
			addpos += 0x0010;
		}
		if (otherpos == 6)
		{
			WAM[((25 << 5) >> 1) + 4] = (themxo * 80);
			while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
			WORLD_HEAD(25,0xC000); // shows the world
			addthem += 0x0020;
			addpos += 0x0020;
		}
		if (otherpos == 7)
		{
			WAM[((24 << 5) >> 1) + 4] = (themxo * 80);
			while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
			WORLD_HEAD(24,0xC000); // shows the world
			addthem += 0x0040;
			addpos += 0x0040;
		}
		if (otherpos == 8)
		{
			WAM[((23 << 5) >> 1) + 4] = (themxo * 80);
			while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
			WORLD_HEAD(23,0xC000); // shows the world
			addthem += 0x0080;
			addpos += 0x0080;
		}
		if (otherpos == 9)
		{
			WAM[((22 << 5) >> 1) + 4] = (themxo * 80);
			while (VIP_REGS[XPSTTS] & XPBSYR); // waits to make sure it doesn't change the worlds while the screen is drawing
			WORLD_HEAD(22,0xC000); // shows the world
			addthem += 0x0100;
			addpos += 0x0100;
		}

		// ends the game if they have a line
		if ((addthem & 0x0007) == 0x0007)
		{
			losses++;
			gameover = 1;
			for (paracount = 0; paracount < 5; paracount++)
			{
				WAM[((30 << 5) >> 1) + 2] --;
				WAM[((29 << 5) >> 1) + 2] --;
				WAM[((28 << 5) >> 1) + 2] --;
				WAM[((27 << 5) >> 1) + 2] ++;
				WAM[((26 << 5) >> 1) + 2] ++;
				WAM[((25 << 5) >> 1) + 2] ++;
				WAM[((24 << 5) >> 1) + 2] ++;
				WAM[((23 << 5) >> 1) + 2] ++;
				WAM[((22 << 5) >> 1) + 2] ++;
				vbWaitFrame(5*realVBSpeed);
			}
		}
		if ((addthem & 0x0038) == 0x0038)
		{
			losses++;
			gameover = 1;
			for (paracount = 0; paracount < 5; paracount++)
			{
				WAM[((30 << 5) >> 1) + 2] ++;
				WAM[((29 << 5) >> 1) + 2] ++;
				WAM[((28 << 5) >> 1) + 2] ++;
				WAM[((27 << 5) >> 1) + 2] --;
				WAM[((26 << 5) >> 1) + 2] --;
				WAM[((25 << 5) >> 1) + 2] --;
				WAM[((24 << 5) >> 1) + 2] ++;
				WAM[((23 << 5) >> 1) + 2] ++;
				WAM[((22 << 5) >> 1) + 2] ++;
				vbWaitFrame(5*realVBSpeed);
			}
		}
		if ((addthem & 0x01C0) == 0x01C0)
		{
			losses++;
			gameover = 1;
			for (paracount = 0; paracount < 5; paracount++)
			{
				WAM[((30 << 5) >> 1) + 2] ++;
				WAM[((29 << 5) >> 1) + 2] ++;
				WAM[((28 << 5) >> 1) + 2] ++;
				WAM[((27 << 5) >> 1) + 2] ++;
				WAM[((26 << 5) >> 1) + 2] ++;
				WAM[((25 << 5) >> 1) + 2] ++;
				WAM[((24 << 5) >> 1) + 2] --;
				WAM[((23 << 5) >> 1) + 2] --;
				WAM[((22 << 5) >> 1) + 2] --;
				vbWaitFrame(5*realVBSpeed);
			}
		}
		if ((addthem & 0x0049) == 0x0049)
		{
			losses++;
			gameover = 1;
			for (paracount = 0; paracount < 5; paracount++)
			{
				WAM[((30 << 5) >> 1) + 2] --;
				WAM[((29 << 5) >> 1) + 2] ++;
				WAM[((28 << 5) >> 1) + 2] ++;
				WAM[((27 << 5) >> 1) + 2] --;
				WAM[((26 << 5) >> 1) + 2] ++;
				WAM[((25 << 5) >> 1) + 2] ++;
				WAM[((24 << 5) >> 1) + 2] --;
				WAM[((23 << 5) >> 1) + 2] ++;
				WAM[((22 << 5) >> 1) + 2] ++;
				vbWaitFrame(5*realVBSpeed);
			}
		}
		if ((addthem & 0x0092) == 0x0092)
		{
			losses++;
			gameover = 1;
			for (paracount = 0; paracount < 5; paracount++)
			{
				WAM[((30 << 5) >> 1) + 2] ++;
				WAM[((29 << 5) >> 1) + 2] --;
				WAM[((28 << 5) >> 1) + 2] ++;
				WAM[((27 << 5) >> 1) + 2] ++;
				WAM[((26 << 5) >> 1) + 2] --;
				WAM[((25 << 5) >> 1) + 2] ++;
				WAM[((24 << 5) >> 1) + 2] ++;
				WAM[((23 << 5) >> 1) + 2] --;
				WAM[((22 << 5) >> 1) + 2] ++;
				vbWaitFrame(5*realVBSpeed);
			}
		}
		if ((addthem & 0x0124) == 0x0124)
		{
			losses++;
			gameover = 1;
			for (paracount = 0; paracount < 5; paracount++)
			{
				WAM[((30 << 5) >> 1) + 2] ++;
				WAM[((29 << 5) >> 1) + 2] ++;
				WAM[((28 << 5) >> 1) + 2] --;
				WAM[((27 << 5) >> 1) + 2] ++;
				WAM[((26 << 5) >> 1) + 2] ++;
				WAM[((25 << 5) >> 1) + 2] --;
				WAM[((24 << 5) >> 1) + 2] ++;
				WAM[((23 << 5) >> 1) + 2] ++;
				WAM[((22 << 5) >> 1) + 2] --;
				vbWaitFrame(5*realVBSpeed);
			}
		}
		if ((addthem & 0x0111) == 0x0111)
		{
			losses++;
			gameover = 1;
			for (paracount = 0; paracount < 5; paracount++)
			{
				WAM[((30 << 5) >> 1) + 2] --;
				WAM[((29 << 5) >> 1) + 2] ++;
				WAM[((28 << 5) >> 1) + 2] ++;
				WAM[((27 << 5) >> 1) + 2] ++;
				WAM[((26 << 5) >> 1) + 2] --;
				WAM[((25 << 5) >> 1) + 2] ++;
				WAM[((24 << 5) >> 1) + 2] ++;
				WAM[((23 << 5) >> 1) + 2] ++;
				WAM[((22 << 5) >> 1) + 2] --;
				vbWaitFrame(5*realVBSpeed);
			}
		}
		if ((addthem & 0x0054) == 0x0054)
		{
			losses++;
			gameover = 1;
			for (paracount = 0; paracount < 5; paracount++)
			{
				WAM[((30 << 5) >> 1) + 2] ++;
				WAM[((29 << 5) >> 1) + 2] ++;
				WAM[((28 << 5) >> 1) + 2] --;
				WAM[((27 << 5) >> 1) + 2] ++;
				WAM[((26 << 5) >> 1) + 2] --;
				WAM[((25 << 5) >> 1) + 2] ++;
				WAM[((24 << 5) >> 1) + 2] --;
				WAM[((23 << 5) >> 1) + 2] ++;
				WAM[((22 << 5) >> 1) + 2] ++;
				vbWaitFrame(5*realVBSpeed);
			}
		}
		
		if (gameover == 1)
		{
			vbWaitFrame(30*realVBSpeed);
			vbDisplayHide();
			ClearWorlds();
			main();
		}
		
		if (addpos == 0x01FF) // board completely filled and no winner
		{
			ties++;
			for (paracount = 0; paracount < 5; paracount++)
			{
				WAM[((30 << 5) >> 1) + 2] ++;
				WAM[((29 << 5) >> 1) + 2] ++;
				WAM[((28 << 5) >> 1) + 2] ++;
				WAM[((27 << 5) >> 1) + 2] ++;
				WAM[((26 << 5) >> 1) + 2] ++;
				WAM[((25 << 5) >> 1) + 2] ++;
				WAM[((24 << 5) >> 1) + 2] ++;
				WAM[((23 << 5) >> 1) + 2] ++;
				WAM[((22 << 5) >> 1) + 2] ++;
				vbWaitFrame(5*realVBSpeed);
			}
			vbWaitFrame(70*realVBSpeed);
			vbDisplayHide();
			ClearWorlds();
			main();
		}

		turnover = 0; // makes it this VB's turn again
	}
	
	return 0;	
}