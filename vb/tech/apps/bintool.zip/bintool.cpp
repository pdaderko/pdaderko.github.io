//Binary file even/odd byte splitting and merging tool by Pat Daderko (DogP@comcast.net)

#include <iostream.h>
#include <fstream.h>
#include <cstring>

void printusage()
{
	cout <<
		"Incorrect Syntax." << endl <<
		endl << 
		"Binary file even/odd byte splitting and merging tool by Pat Daderko" << endl <<
		"(DogP@comcast.net)" << endl <<
		endl <<
		"Usage:" << endl << 
		"Split - bintool /s <source> <even destination> <odd destination>" << endl <<
		"Merge - bintool /m <even source> <odd source> <destination>" << endl;
}

int main(int argc, char *argv[])
{
	ofstream evenoutfile;
	ofstream oddoutfile;
	ifstream combineinfile;
	
	ifstream eveninfile;
	ifstream oddinfile;
	ofstream combineoutfile;

	char count = 0;
	char temp;

	if (argc != 5)
		printusage();

	//merge (/m)
	else if (!strcmp(argv[1], "/m"))
	{
		//open inputs as binary files
		eveninfile.open(argv[2], ifstream::binary | ifstream::ate);
		oddinfile.open(argv[3], ifstream::binary | ifstream::ate);

		//check to make sure both files are same length
		if (eveninfile.tellg() != oddinfile.tellg())
		{
			cout << "Source files must be same size." << endl;
			eveninfile.close();
			oddinfile.close();
			combineoutfile.close();
			return 1;
		}

		//open output if no problems, and seek to the beginning of inputs
		combineoutfile.open(argv[4], ofstream::binary);
		eveninfile.seekg(0);
		oddinfile.seekg(0);

		//check to make sure file opened successfully
		if ((!eveninfile.is_open()) || (!oddinfile.is_open()) || (!combineoutfile.is_open()))
		{
			cout << "Error opening file(s)" << endl;
			eveninfile.close();
			oddinfile.close();
			return 1;
		}

		while (1)
		{
			if (count & 1)
			{
				oddinfile.get(temp);
				if (!oddinfile.eof())
					combineoutfile.put(temp);
				else
					break;
			}
			else
			{
				eveninfile.get(temp);
				if (!eveninfile.eof())
					combineoutfile.put(temp);
				else
					break;
			}
			count ^= 1;
		}
		eveninfile.close();
		oddinfile.close();
		combineoutfile.close();
		cout << "Merging Done!";
	}

	//split (/s)
	else if (!strcmp(argv[1], "/s"))
	{
		//open as binary files
		combineinfile.open(argv[2], ifstream::binary);
		evenoutfile.open(argv[3], ofstream::binary);
		oddoutfile.open(argv[4], ofstream::binary);

		//check to make sure file opened successfully
		if ((!combineinfile.is_open()) || (!evenoutfile.is_open()) || (!oddoutfile.is_open()))
		{
			cout << "Error opening file(s)" << endl;
			combineinfile.close();
			oddoutfile.close();
			evenoutfile.close();
			return 1;
		}

		while (1)
		{
			if (count & 1)
			{
				combineinfile.get(temp);
				if (!combineinfile.eof())
					oddoutfile.put(temp);
				else
					break;
			}
			else
			{
				combineinfile.get(temp);
				if (!combineinfile.eof())
					evenoutfile.put(temp);
				else
					break;
			}
			count ^= 1;
		}

		//close files
		combineinfile.close();
		oddoutfile.close();
		evenoutfile.close();
		cout << "Splitting Done!";
	}
	else
		printusage();

	return 0;
}