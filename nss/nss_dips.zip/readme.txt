Nintendo Super System DIP Switch Patcher 1.0 by Pat Daderko (DogP)

This program patches Nintendo Super System ROMs with DIP switch settings, so they can be used without hardware DIP switches (i.e. from a flash cartridge), for use on the Super System or SNES.

There are five games that support DIP switches:
ActRaiser
Addams Family
Lethal Weapon
Magic Floor (homebrew)
Robocop 3

The ROMs must already be a single file, playable on the SNES (not multiple ROM files like the MAME dumps).

Usage:
nss_dips.exe <Super System ROM> [<DIP Switches> [Output ROM File]]
Or drag and drop a ROM file on the application

Enter <DIP Switches> as 1 (on) or 0 (off) in order of switch 1 to 8
Default output filename appends _DIP.smc to the input file (minus the original file extension)